import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Shield, 
  Download, 
  CheckCircle, 
  Mail,
  Crown,
  Linkedin
} from "lucide-react";
import timSuttonPhoto from "../../../attached_assets/Picture1_1752830766958.jpg";
import gammaScreenshot from "../../../attached_assets/Screenshot 2025-07-23 at 09.47.47_1753260470832.png";

export default function Home() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isMobile, setIsMobile] = useState(false);
  const [isQuickContactOpen, setIsQuickContactOpen] = useState(false);
  
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);
    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    serviceInterest: "",
    message: ""
  });

  const [quickContactData, setQuickContactData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    serviceInterest: "emergency-crisis",
    message: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast({
          title: "Message Sent Successfully",
          description: "Thank you for your inquiry. We'll get back to you within 24 hours.",
        });
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          phone: "",
          company: "",
          serviceInterest: "",
          message: ""
        });
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Message Failed",
        description: "There was an issue sending your message. Please try again or contact us directly.",
        variant: "destructive",
      });
    }
  };

  const handleQuickContact = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(quickContactData),
      });

      if (response.ok) {
        toast({
          title: "Message Sent Successfully",
          description: "Thank you for your inquiry. We'll get back to you within 24 hours.",
        });
        setQuickContactData({
          firstName: "",
          lastName: "",
          email: "",
          phone: "",
          company: "",
          serviceInterest: "emergency-crisis",
          message: ""
        });
        setIsQuickContactOpen(false);
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Message Failed",
        description: "There was an issue sending your message. Please try again or contact us directly.",
        variant: "destructive",
      });
    }
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  return (
    <div className="min-h-screen"
         style={{ 
           background: '#ffffff', 
           color: '#1a1a1a',
           fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
         }}>
      {/* Gamma Pro Navigation */}
      <header role="banner">
        <nav className="sticky top-0 z-50" role="navigation" aria-label="Main navigation"
             style={{ 
               background: '#ffffff', 
               borderBottom: '1px solid #e5e5e5'
             }}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              {/* Gamma Pro Profile Header */}
              <Link href="/" className="flex items-center space-x-3 group">
                <img 
                  src={timSuttonPhoto} 
                  alt="Tim Sutton - Crisis Management Expert and Strategy Consultant" 
                  className="h-12 w-12 rounded-full object-cover border-2 transition-all duration-300"
                  style={{ borderColor: 'hsl(217, 91%, 50%)' }}
                  width="48" 
                  height="48"
                />
                <div className="hidden sm:block">
                  <h2 className="text-lg font-bold transition-all duration-300"
                      style={{ color: 'hsl(217, 91%, 50%)' }}>
                    Tim Sutton Strategy
                  </h2>
                  <p className="text-xs" style={{ color: 'hsl(240, 10%, 3.9%)' }}>Crisis Management Expert</p>
                </div>
              </Link>
              
              {/* Gamma Pro Navigation Links */}
              <div className="hidden md:flex items-center space-x-4">
                <Link 
                  href="/about"
                  className="px-4 py-2 rounded-lg font-medium hover:opacity-80 transition-all duration-300"
                  style={{ color: 'hsl(217, 91%, 50%)' }}
                  aria-label="Navigate to About page"
                >
                  About Tim
                </Link>

                <button 
                  onClick={() => scrollToSection('packages')} 
                  className="px-4 py-2 rounded-lg font-medium hover:opacity-80 transition-all duration-300"
                  style={{ color: 'hsl(217, 91%, 50%)' }}
                  aria-label="Navigate to Digital Crisis Solutions section"
                >
                  Digital Crisis Solutions
                </button>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="px-4 py-2 rounded-lg font-medium hover:opacity-80 transition-all duration-300"
                  style={{ color: 'hsl(217, 91%, 50%)' }}
                  aria-label="Navigate to Contact section"
                >
                  Contact
                </button>
              </div>
              
              {/* Mobile Menu Button */}
              <div className="md:hidden">
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="p-2 rounded-lg hover:opacity-80 transition-all duration-300"
                  style={{ color: 'hsl(217, 91%, 50%)' }}
                >
                  <div className={`w-6 h-0.5 transition-all duration-300 ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`}
                       style={{ background: 'hsl(217, 91%, 50%)' }}></div>
                  <div className={`w-6 h-0.5 my-1 transition-all duration-300 ${mobileMenuOpen ? 'opacity-0' : ''}`}
                       style={{ background: 'hsl(217, 91%, 50%)' }}></div>
                  <div className={`w-6 h-0.5 transition-all duration-300 ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}
                       style={{ background: 'hsl(217, 91%, 50%)' }}></div>
                </button>
              </div>
            </div>
            
            {/* Modern Mobile Menu */}
            {mobileMenuOpen && (
              <div className="md:hidden pb-6">
                <div className="modern-mobile-menu">
                  <Link 
                    href="/about"
                    onClick={() => setMobileMenuOpen(false)}
                    className="modern-mobile-link group"
                  >
                    <span>About Tim</span>
                    <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>

                  <button 
                    onClick={() => { scrollToSection('packages'); setMobileMenuOpen(false); }} 
                    className="modern-mobile-link group"
                  >
                    <span>Digital Crisis Solutions</span>
                    <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                  <button 
                    onClick={() => { scrollToSection('contact'); setMobileMenuOpen(false); }} 
                    className="modern-mobile-cta"
                  >
                    <span>Contact</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </nav>
      </header>



      {/* EXACT GAMMA PRESENTATION REPLICA */}
      <main style={{ padding: '40px 20px', maxWidth: '800px', margin: '0 auto' }}>
        
        {/* Title - Exact Gamma Style */}
        <div style={{ marginBottom: '48px' }}>
          <h1 className="gamma-heading" 
              style={{ 
                fontSize: '48px',
                fontWeight: '700',
                lineHeight: '1.2',
                textAlign: 'center',
                marginBottom: '32px'
              }}>
            The Complete 24 Hour Crisis Management Plan for any Business
          </h1>
        </div>

        {/* Product Overview - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h2 className="gamma-subheading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                marginBottom: '24px'
              }}>
            Product Overview
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '12px'
                  }}>
                Target Pain Point:
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Businesses often face overwhelming uncertainty and panic during the critical first 24 hours of a crisis, feeling lost on what to do.
              </p>
            </div>
            
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '12px'
                  }}>
                Product Promise:
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Transform panic into purposeful, guided action with a proven, step-by-step system that navigates you through the critical first 24 hours of any business crisis.
              </p>
            </div>
          </div>
        </div>

        {/* Who This Is For - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h2 className="gamma-subheading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                marginBottom: '24px'
              }}>
            Who This Is For:
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
            <div>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '16px' }}>
                Small to mid-sized business (SMB) owners navigating their first significant operational disruption, reputational damage, or a critical public relations incident.
              </p>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Department managers and team leaders who require immediate, actionable guidance to steer their teams through unforeseen challenges like data breaches or supply chain failures.
              </p>
            </div>
            
            <div>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '16px' }}>
                Any individual or team responsible for initial crisis response who feels overwhelmed by the lack of a structured plan, fearing critical missteps in the chaotic first hours of an emergency.
              </p>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Executive leaders and strategic decision-makers committed to protecting their organization's reputation, financial stability, and legal standing by proactively implementing a robust crisis response framework.
              </p>
            </div>
          </div>
        </div>

        {/* Table of Contents - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h2 className="gamma-subheading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                marginBottom: '24px'
              }}>
            Table of Contents
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '20px' }}>
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                PART 1: IMMEDIATE CRISIS RESPONSE (Hours 0-1)
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Rapid action, team activation, and initial communication for the critical first hour.
              </p>
            </div>
            
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                PART 2: CRISIS STABILIZATION (Hours 1-6)
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Comprehensive assessment, stakeholder notification, and resource mobilization to stabilize the situation.
              </p>
            </div>
            
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                PART 3: STRATEGIC RESPONSE (Hours 6-12)
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Developing long-term response strategies, managing public relations, and ensuring operational continuity.
              </p>
            </div>
            
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                PART 4: RECOVERY PREPARATION (Hours 12-24)
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Planning for post-crisis recovery, rebuilding relationships, and preparing for the next phase.
              </p>
            </div>
            
            <div>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                PART 5: TEMPLATES AND CHECKLISTS
              </h3>
              <p className="gamma-body" style={{ fontSize: '16px', lineHeight: '1.6' }}>
                Over 15 ready-to-use templates, hour-by-hour checklists, flowcharts, and communication scripts.
              </p>
            </div>
          </div>
        </div>

        {/* How to Use This System - Emergency Mode - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h2 className="gamma-subheading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                marginBottom: '24px'
              }}>
            How to Use This System
          </h2>
          
          <h3 className="gamma-subheading" 
              style={{ 
                fontSize: '24px',
                fontWeight: '600',
                marginBottom: '16px'
              }}>
            EMERGENCY MODE (Crisis is happening NOW)
          </h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
            <div>
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Go directly to PART 1
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Start with Hour 0 actions to initiate rapid response.
                </p>
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Follow the hour-by-hour checklist
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Ensure every critical step is completed without skipping.
                </p>
              </div>
            </div>
            
            <div>
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Use templates immediately
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Leverage pre-designed templates and customize them as you proceed.
                </p>
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Delegate using role assignments
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Distribute tasks to your team; avoid trying to manage everything yourself.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* How to Use This System - Preparation Mode - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h3 className="gamma-subheading" 
              style={{ 
                fontSize: '24px',
                fontWeight: '600',
                marginBottom: '16px'
              }}>
            PREPARATION MODE (Before crisis hits)
          </h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
            <div>
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Read through the entire system
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Understand the flow of the entire plan, from immediate response to recovery.
                </p>
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Customize templates
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Pre-fill all relevant information and details into the provided templates to save critical time during a crisis.
                </p>
              </div>
            </div>
            
            <div>
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Assign roles
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Clearly define and assign roles and responsibilities to each team member so everyone knows their part during a crisis.
                </p>
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <h4 className="gamma-subheading" 
                    style={{ 
                      fontSize: '16px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                  Practice with exercises
                </h4>
                <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                  Conduct tabletop exercises and drills to test the system's effectiveness and identify any areas for improvement before a real crisis hits.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Key Success Factors - Exact Gamma Card */}
        <div className="gamma-card" style={{ marginBottom: '32px' }}>
          <h2 className="gamma-subheading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                marginBottom: '24px',
                textAlign: 'center'
              }}>
            ⚡ KEY SUCCESS FACTORS
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '24px' }}>
            <div style={{ textAlign: 'center' }}>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                Speed Over Perfection
              </h3>
              <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                Prioritize rapid action and iterate as you go.
              </p>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                Communication is Critical
              </h3>
              <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                Ensure all stakeholders are promptly informed.
              </p>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                Document Everything
              </h3>
              <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                Maintain detailed records for future reference.
              </p>
            </div>
            
            <div style={{ textAlign: 'center' }}>
              <h3 className="gamma-subheading" 
                  style={{ 
                    fontSize: '18px',
                    fontWeight: '600',
                    marginBottom: '8px'
                  }}>
                Stay Calm & Systematic
              </h3>
              <p className="gamma-body" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                Trust the established system to guide you through.
              </p>
            </div>
          </div>
        </div>

        {/* Add Tim Sutton Professional Photo */}
        <div className="gamma-card" style={{ marginBottom: '32px', textAlign: 'center' }}>
          <img 
            src={professionalPhoto} 
            alt="Tim Sutton - Crisis Management Expert"
            style={{ 
              width: 'auto',
              height: '300px',
              borderRadius: '8px',
              margin: '0 auto 24px auto',
              display: 'block'
            }}
          />
          <div style={{ textAlign: 'center' }}>
            <img 
              src={testimonialPhoto} 
              alt="Professional Recognition"
              style={{ 
                width: '100%',
                maxWidth: '600px',
                height: 'auto',
                borderRadius: '8px',
                margin: '0 auto'
              }}
            />
          </div>
        </div>
      </main>

      {/* Packages Section - Payment System */}  
      <section id="packages" className="gamma-section" style={{ background: '#f8f9fa', padding: '60px 0' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto', padding: '0 20px' }}>
          <h2 className="gamma-heading" 
              style={{ 
                fontSize: '32px',
                fontWeight: '600',
                textAlign: 'center',
                marginBottom: '32px'
              }}>
            Get Your Complete Crisis Management System
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
            {/* Crisis-Ready Package */}
            <div className="gamma-card">
              <h3 className="gamma-subheading" style={{ fontSize: '24px', marginBottom: '16px' }}>
                Crisis-Ready in One Day
              </h3>
              <div style={{ fontSize: '36px', fontWeight: '700', marginBottom: '16px', color: '#1a1a1a' }}>
                $199
              </div>
              <p className="gamma-body" style={{ marginBottom: '24px' }}>
                Complete 24-hour crisis management system with all templates and checklists
              </p>
              <div style={{ display: 'flex', gap: '12px', flexDirection: 'column' }}>
                <button 
                  onClick={() => {
                    window.location.href = '/checkout?package=crisis-ready&amount=199';
                  }}
                  style={{
                    background: '#1a1a1a',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}
                >
                  Pay with Stripe
                </button>
                <a 
                  href="https://suttonian016.gumroad.com/l/etdkl"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    background: '#ffffff',
                    color: '#1a1a1a',
                    border: '1px solid #e1e5e9',
                    borderRadius: '6px',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    textDecoration: 'none',
                    textAlign: 'center',
                    display: 'block'
                  }}
                >
                  Buy on Gumroad
                </a>
              </div>
            </div>

            {/* Executive Package */}
            <div className="gamma-card">
              <h3 className="gamma-subheading" style={{ fontSize: '24px', marginBottom: '16px' }}>
                Executive Crisis Plan
              </h3>
              <div style={{ fontSize: '36px', fontWeight: '700', marginBottom: '16px', color: '#1a1a1a' }}>
                $499
              </div>
              <p className="gamma-body" style={{ marginBottom: '24px' }}>
                Premium system plus personal consultation with Tim Sutton
              </p>
              <div style={{ display: 'flex', gap: '12px', flexDirection: 'column' }}>
                <button 
                  onClick={() => {
                    window.location.href = '/checkout?package=executive&amount=499';
                  }}
                  style={{
                    background: '#1a1a1a',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}
                >
                  Pay with Stripe
                </button>
                <a 
                  href="https://suttonian016.gumroad.com/l/dxjkrs"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    background: '#ffffff',
                    color: '#1a1a1a',
                    border: '1px solid #e1e5e9',
                    borderRadius: '6px',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    textDecoration: 'none',
                    textAlign: 'center',
                    display: 'block'
                  }}
                >
                  Buy on Gumroad
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ 
        background: '#f8f9fa', 
        borderTop: '1px solid #e1e5e9',
        padding: '40px 20px',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <p className="gamma-body" style={{ marginBottom: '16px' }}>
            © 2025 Tim Sutton Strategy Consulting. All rights reserved.
          </p>
          <p className="gamma-body">
            Professional crisis management solutions for businesses worldwide.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
            <p className="text-xl max-w-3xl mx-auto leading-relaxed"
               style={{ color: 'hsl(240, 10%, 3.9%)' }}>
              Get immediate access to professional crisis management frameworks and templates 
              that have protected businesses worldwide.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Crisis-Ready Package */}
            <div className="gamma-card p-8 rounded-xl border-2 relative hover:shadow-lg transition-all duration-300"
                 style={{ borderColor: 'hsl(217, 91%, 50%)' }}>
              <div className="absolute -top-3 left-6">
                <span className="text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg"
                      style={{ background: 'hsl(217, 91%, 50%)' }}>🔥 POPULAR</span>
              </div>
              
              <div className="text-center mb-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                     style={{ background: 'hsl(217, 91%, 50%)' }}>
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3" style={{ color: 'hsl(217, 91%, 50%)' }}>Crisis-Ready in One Day</h3>
                <div className="text-5xl font-bold mb-4" style={{ color: 'hsl(217, 91%, 50%)' }}>$199</div>
                <p className="text-lg leading-relaxed" style={{ color: 'hsl(240, 10%, 3.9%)' }}>Complete crisis management system with templates and checklists</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">24-hour step-by-step crisis response plan</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">15+ professional templates and checklists</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">Email and social media crisis templates</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">Industry-specific playbooks</span>
                </div>
              </div>

              <div className="space-y-3">
                <Link href="/checkout?package=crisis-ready" className="block">
                  <button className="w-full gamma-blue text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
                    Pay with Stripe
                  </button>
                </Link>
                <a 
                  href="https://suttonian016.gumroad.com/l/etdkl" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block"
                >
                  <button className="w-full gamma-orange text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
                    Buy on Gumroad
                  </button>
                </a>
              </div>
            </div>

            {/* Executive Package */}
            <div className="gamma-card p-8 rounded-xl border-2 relative hover:shadow-lg transition-all duration-300"
                 style={{ borderColor: 'hsl(267, 70%, 70%)' }}>
              <div className="absolute -top-3 left-6">
                <span className="text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg"
                      style={{ background: 'hsl(267, 70%, 70%)' }}>⭐ PREMIUM</span>
              </div>
              
              <div className="text-center mb-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                     style={{ background: 'hsl(267, 70%, 70%)' }}>
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3" style={{ color: 'hsl(217, 91%, 50%)' }}>Executive Crisis Plan</h3>
                <div className="text-5xl font-bold mb-4" style={{ color: 'hsl(267, 70%, 70%)' }}>$499</div>
                <p className="text-lg leading-relaxed" style={{ color: 'hsl(240, 10%, 3.9%)' }}>Everything in Crisis-Ready plus personal consultation</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">Everything in Crisis-Ready package</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">60-minute personal consultation with Tim</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">Customized crisis response strategy</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="gamma-text">Priority email support for 30 days</span>
                </div>
              </div>

              <div className="space-y-3">
                <Link href="/checkout?package=executive" className="block">
                  <button className="w-full gamma-orange text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
                    Pay with Stripe
                  </button>
                </Link>
                <a 
                  href="https://suttonian016.gumroad.com/l/dxjkrs" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block"
                >
                  <button className="w-full gamma-orange text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
                    Buy on Gumroad
                  </button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer - Clean Gamma Style */}
      <footer className="gamma-section" 
              style={{ 
                background: '#f8f9fa', 
                borderTop: '1px solid #e5e5e5',
                color: '#1a1a1a' 
              }}>
        <div className="gamma-container">
          <div className="text-center space-y-6">
            <div className="flex items-center justify-center space-x-4">
              <img 
                src={timSuttonPhoto} 
                alt="Tim Sutton" 
                className="w-16 h-16 rounded-full object-cover border-2 shadow-lg"
                style={{ borderColor: 'hsl(217, 91%, 50%)' }}
              />
              <div className="text-left">
                <h3 className="text-xl font-bold" style={{ color: 'hsl(217, 91%, 50%)' }}>
                  Tim Sutton Strategy Consulting
                </h3>
                <p className="text-lg" style={{ color: 'hsl(240, 10%, 3.9%)' }}>Crisis Management & Strategic Communications</p>
              </div>
            </div>
            
            <div className="flex justify-center space-x-6">
              <a 
                href="https://linkedin.com/in/timothysutton1/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:opacity-80 transition-colors"
                style={{ color: 'hsl(217, 91%, 50%)' }}
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <button 
                onClick={() => setIsQuickContactOpen(true)}
                className="hover:opacity-80 transition-colors"
                style={{ color: 'hsl(217, 91%, 50%)' }}
              >
                <Mail className="w-6 h-6" />
              </button>
            </div>
            
            <div className="text-sm" style={{ color: 'hsl(240, 10%, 3.9%)' }}>
              <p>&copy; 2025 Tim Sutton Strategy Consulting. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Quick Contact Dialog */}
      <Dialog open={isQuickContactOpen} onOpenChange={setIsQuickContactOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Quick Contact</DialogTitle>
          </DialogHeader>
          <div className="text-center space-y-4">
            <p className="text-gray-600">
              Get in touch for crisis management consultation or questions about our packages.
            </p>
            <div className="space-y-3">
              <a 
                href="mailto:tsutton22@icloud.com"
                className="block bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
                onClick={() => setIsQuickContactOpen(false)}
              >
                Send Email
              </a>
              <a 
                href="https://linkedin.com/in/timothysutton1/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block bg-blue-700 text-white px-6 py-3 rounded-lg hover:bg-blue-800 transition-colors"
                onClick={() => setIsQuickContactOpen(false)}
              >
                LinkedIn Message
              </a>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
