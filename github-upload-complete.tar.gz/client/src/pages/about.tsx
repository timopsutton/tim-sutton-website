import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Award, 
  Building2, 
  Globe, 
  Users, 
  TrendingUp,
  Star,
  CheckCircle,
  Briefcase,
  GraduationCap,
  Phone,
  Mail,
  Linkedin
} from "lucide-react";
import timSuttonPhoto from "@assets/tim-sutton-photo.jpg";

export default function About() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    serviceInterest: "",
    message: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast({
          title: "Message Sent Successfully",
          description: "Thank you for your inquiry. We'll get back to you within 24 hours.",
        });
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          phone: "",
          company: "",
          serviceInterest: "",
          message: ""
        });
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Message Failed",
        description: "There was an issue sending your message. Please try again or contact us directly.",
        variant: "destructive",
      });
    }
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation Header */}
      <nav className="bg-slate-900/80 backdrop-blur-sm border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-3 text-white hover:text-yellow-400 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-semibold">Back to Home</span>
            </Link>
            <div className="text-white font-bold text-lg">Tim Sutton Strategy Consulting</div>
          </div>
        </div>
      </nav>

      {/* Hero Section with Photo */}
      <section className="py-16 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-32 left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-32 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-2xl animate-float-slow"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-full px-6 py-3 mb-8">
              <div className="w-3 h-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-bold tracking-wide uppercase text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">About Tim Sutton</span>
            </div>
            
            {/* Profile Image */}
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full blur opacity-30 animate-glow"></div>
                <img
                  src={timSuttonPhoto}
                  alt="Tim Sutton - Crisis Management Expert"
                  className="relative w-48 h-48 rounded-full object-cover border-4 border-white/20 shadow-2xl"
                />
                <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center border-4 border-slate-900">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>

            {/* LinkedIn Link */}
            <div className="flex justify-center mb-12">
              <a 
                href="https://linkedin.com/in/timothysutton1/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 hover:scale-105 shadow-lg border border-blue-500/30"
              >
                <Linkedin className="w-6 h-6" />
                Find me on LinkedIn
              </a>
            </div>

            <h1 className="text-4xl lg:text-6xl font-black text-white leading-tight mb-6">
              Meet <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">Tim Sutton</span>
            </h1>
            
            <p className="text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed mb-8">
              Chairman of W Communications & a leading independent PR Consultant • Crisis Management Expert • Strategic Communications Advisor • M&A Consultant
            </p>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="text-3xl font-black text-yellow-400 mb-2">35+</div>
                <div className="text-sm text-slate-300">Years PR Advisory Experience</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="text-3xl font-black text-orange-400 mb-2">40+</div>
                <div className="text-sm text-slate-300">Led Global Operations in 40+ Markets Across EMEA & Asia Pacific</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="text-3xl font-black text-blue-400 mb-2">1,600+</div>
                <div className="text-sm text-slate-300">Team Members Led</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="text-3xl font-black text-green-400 mb-2">$60M+</div>
                <div className="text-sm text-slate-300">M&A Deals supporting both buyers & sellers</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Professional Background */}
      <section className="pt-2 pb-16 bg-gradient-to-r from-slate-800/50 to-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            
            {/* Left Column - Bio */}
            <div>
              <h2 className="text-3xl lg:text-4xl font-black text-white mb-8">Professional Background</h2>
              
              <div className="space-y-6 text-slate-300 leading-relaxed">
                <p>
                  Tim's global PR leadership experience spans EMEA and Asia Pacific regions, where he successfully managed teams of 1,600+ employees.
                </p>
                
                <p>
                  With over 35 years of Corporate Affairs experience, Tim Sutton has guided major blue chip brands, governments, NGOs, and UN institutions. He has wide experience across many sectors, including, Aviation, Oil & Gas, Financial Services, Food & Drink and the Voluntary Sector.
                </p>
                
                <p>
                  His expertise includes issues and crisis management, ESG services, brand strategy, board level consultancy and complex communications challenges that require both strategic thinking and tactical execution.
                </p>
                
                <p>
                  Looking for the right PR Agency to buy? Tim has a wide global network and has helped many clients identify the right acquisition opportunities. He combines strategic communications expertise with extensive transaction experience.
                </p>
              </div>

              {/* Quote */}
              <div className="mt-12 p-8 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-l-4 border-yellow-500 rounded-lg">
                <blockquote className="text-xl italic text-white mb-4">
                  "Tim is properly wise. Almost sage," said David Brain, who worked alongside Sutton at Charles Barker. "A lot of senior practitioners in PR are clever or smart and as an industry we put a huge emphasis on interpreting trends, understanding the market or reacting to events, but Tim is one of those rare people that can also step back and bring perspective and calm and remain focused on the big picture. It is a rare talent and one of the reasons he is amongst the very best CEO whisperers..."
                </blockquote>
                <cite className="text-yellow-400 font-semibold">— David Brain, Former Global Head of Edelman</cite>
              </div>
            </div>


          </div>
        </div>
      </section>

      {/* Media & Speaking */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-black text-white mb-4">Media & Speaking</h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              Tim regularly shares his expertise through industry publications, podcasts, and speaking engagements.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Award className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">PublicAffairsAsia</h3>
              <p className="text-slate-300 text-sm">Gold Standard Awards interview feature</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">ANC Shoptalk</h3>
              <p className="text-slate-300 text-sm">Television appearance on PR evolution</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">PRovoke Media</h3>
              <p className="text-slate-300 text-sm">Podcast expert commentary</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">Industry Articles</h3>
              <p className="text-slate-300 text-sm">Data privacy and ethics thought leadership</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contact" className="py-16 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
        {/* Premium Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-16 left-16 w-80 h-80 bg-gradient-to-r from-yellow-500/8 to-orange-500/8 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-16 right-16 w-72 h-72 bg-gradient-to-r from-blue-500/6 to-purple-500/6 rounded-full blur-2xl animate-float-slow"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-amber-500/4 to-orange-500/4 rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl mb-4 shadow-lg">
              <Mail className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-black text-white mb-3">Need Personal Consultation?</h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              Let's talk about your goals—reach out to arrange a personal strategy session tailored to you.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-10">
            {/* Premium Contact Form */}
            <div className="contact-form-container">
              <h3 className="text-2xl font-bold text-white mb-6">Get In Touch</h3>
              <form onSubmit={handleSubmit} className="premium-contact-form space-y-5">
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="form-field">
                    <Label htmlFor="firstName" className="form-label">First Name</Label>
                    <Input 
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                      className="premium-input"
                      required
                    />
                  </div>
                  <div className="form-field">
                    <Label htmlFor="lastName" className="form-label">Last Name</Label>
                    <Input 
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                      className="premium-input"
                      required
                    />
                  </div>
                </div>
                <div className="form-field">
                  <Label htmlFor="email" className="form-label">Email Address</Label>
                  <Input 
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="premium-input"
                    required
                  />
                </div>
                <div className="form-field">
                  <Label htmlFor="phone" className="form-label">Phone Number (Optional)</Label>
                  <Input 
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="premium-input"
                  />
                </div>
                <div className="form-field">
                  <Label htmlFor="company" className="form-label">Company</Label>
                  <Input 
                    id="company"
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                    className="premium-input"
                    required
                  />
                </div>
                <div className="form-field">
                  <Label htmlFor="serviceInterest" className="form-label">Crisis Management Need</Label>
                  <select 
                    id="serviceInterest"
                    value={formData.serviceInterest}
                    onChange={(e) => setFormData({...formData, serviceInterest: e.target.value})}
                    className="w-full h-10 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-black focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  >
                    <option value="">Select your priority...</option>
                    <option value="emergency-crisis">Emergency Crisis Response</option>
                    <option value="crisis-preparedness">Crisis Preparedness Planning</option>
                    <option value="reputation-management">Reputation Management</option>
                    <option value="media-relations">Crisis Media Relations</option>
                    <option value="sme-package">SME Crisis Package ($199)</option>
                    <option value="executive-package">Executive Package ($499)</option>
                    <option value="personal-consultation">Personal Consultation</option>
                  </select>
                </div>
                <div className="form-field">
                  <Label htmlFor="message" className="form-label">Message</Label>
                  <Textarea 
                    id="message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="premium-input"
                    placeholder="Describe your situation or crisis management needs..."
                    required
                  />
                </div>
                <Button type="submit" className="premium-submit-button w-full">
                  <span className="relative z-10 flex items-center justify-center">
                    <Mail className="w-5 h-5 mr-2" />
                    Send Secure Message
                  </span>
                </Button>
              </form>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}