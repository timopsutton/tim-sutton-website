import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const GammaReplica = () => {
  const [isQuickContactOpen, setIsQuickContactOpen] = useState(false);
  const { toast } = useToast();

  const handleQuickContact = () => {
    setIsQuickContactOpen(true);
  };

  const onSubmit = async (data: any) => {
    try {
      await apiRequest('POST', '/api/contact', data);
      toast({
        title: "Message sent successfully!",
        description: "I'll get back to you within 24 hours.",
      });
      setIsQuickContactOpen(false);
    } catch (error) {
      toast({
        title: "Error sending message",
        description: "Please try again or contact me directly at tsutton22@icloud.com",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="gamma-app">
      {/* Gamma-style Navigation */}
      <nav className="gamma-nav">
        <div className="gamma-nav-content">
          <h1 className="gamma-nav-title">Tim Sutton Crisis Management</h1>
          <button className="gamma-nav-button" onClick={handleQuickContact}>
            Contact
          </button>
        </div>
      </nav>

      {/* Main Gamma Card Container */}
      <div className="gamma-container">
        <div className="gamma-main-card">
          
          {/* Hero Section - Gamma Style */}
          <section className="gamma-section">
            <h1 className="gamma-hero-title">
              The Complete 24-Hour Crisis Management Plan for any Business
            </h1>
            
            <div className="gamma-subtitle-card">
              <h2 className="gamma-subtitle">Product Overview</h2>
              <div className="gamma-text-block">
                <p><strong>Target Pain Point:</strong></p>
                <p>Businesses often face overwhelming uncertainty and panic during the critical first 24 hours of a crisis, feeling lost on what to do.</p>
              </div>
              <div className="gamma-text-block">
                <p><strong>Product Promise:</strong></p>
                <p>Transform panic into purposeful, guided action with a proven, step-by-step system that navigates you through the critical first 24 hours of any business crisis.</p>
              </div>
            </div>
          </section>

          {/* Stats Section - Exact Gamma Style */}
          <section className="gamma-section">
            <div className="gamma-stats-pill">
              <div className="gamma-stat">
                <div className="gamma-stat-icon gamma-green">🛡️</div>
                <span className="gamma-stat-text">$320M+ Losses Prevented</span>
              </div>
              <div className="gamma-stat">
                <div className="gamma-stat-icon gamma-yellow">🏆</div>
                <span className="gamma-stat-text">50+ Crisis Resolutions</span>
              </div>
              <div className="gamma-stat">
                <div className="gamma-stat-icon gamma-green">✅</div>
                <span className="gamma-stat-text">100% Success Rate</span>
              </div>
            </div>
          </section>

          {/* Who This Is For - Gamma Card Style */}
          <section className="gamma-section">
            <div className="gamma-content-card">
              <h2 className="gamma-section-title">Who This Is For:</h2>
              <div className="gamma-list">
                <div className="gamma-list-item">
                  <strong>Small to mid-sized business (SMB) owners</strong> navigating their first significant operational disruption, reputational damage, or a critical public relations incident.
                </div>
                <div className="gamma-list-item">
                  <strong>Department managers and team leaders</strong> who require immediate, actionable guidance to steer their teams through unforeseen challenges like data breaches or supply chain failures.
                </div>
                <div className="gamma-list-item">
                  <strong>Any individual or team responsible for initial crisis response</strong> who feels overwhelmed by the lack of a structured plan, fearing critical missteps in the chaotic first hours of an emergency.
                </div>
                <div className="gamma-list-item">
                  <strong>Executive leaders and strategic decision-makers</strong> committed to protecting their organization's reputation, financial stability, and legal standing by proactively implementing a robust crisis response framework.
                </div>
              </div>
            </div>
          </section>

          {/* Table of Contents - Gamma Style */}
          <section className="gamma-section">
            <div className="gamma-content-card">
              <h2 className="gamma-section-title">Table of Contents</h2>
              <div className="gamma-toc">
                <div className="gamma-toc-item">
                  <h3 className="gamma-toc-title">PART 1: IMMEDIATE CRISIS RESPONSE (Hours 0-1)</h3>
                  <p className="gamma-toc-desc">Rapid action, team activation, and initial communication for the critical first hour.</p>
                </div>
                <div className="gamma-toc-item">
                  <h3 className="gamma-toc-title">PART 2: CRISIS STABILIZATION (Hours 1-6)</h3>
                  <p className="gamma-toc-desc">Comprehensive assessment, stakeholder notification, and resource mobilization to stabilize the situation.</p>
                </div>
                <div className="gamma-toc-item">
                  <h3 className="gamma-toc-title">PART 3: STRATEGIC RESPONSE (Hours 6-12)</h3>
                  <p className="gamma-toc-desc">Developing long-term response strategies, managing public relations, and ensuring operational continuity.</p>
                </div>
                <div className="gamma-toc-item">
                  <h3 className="gamma-toc-title">PART 4: RECOVERY PREPARATION (Hours 12-24)</h3>
                  <p className="gamma-toc-desc">Planning for post-crisis recovery, rebuilding relationships, and preparing for the next phase.</p>
                </div>
                <div className="gamma-toc-item">
                  <h3 className="gamma-toc-title">PART 5: TEMPLATES AND CHECKLISTS</h3>
                  <p className="gamma-toc-desc">Over 15 ready-to-use templates, hour-by-hour checklists, flowcharts, and communication scripts.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Key Success Factors - Gamma Highlight Card */}
          <section className="gamma-section">
            <div className="gamma-highlight-card">
              <h2 className="gamma-highlight-title">⚡ KEY SUCCESS FACTORS</h2>
              <div className="gamma-key-factors">
                <div className="gamma-factor">
                  <h3 className="gamma-factor-title">Speed Over Perfection</h3>
                  <p className="gamma-factor-text">Prioritize rapid action and iterate as you go.</p>
                </div>
                <div className="gamma-factor">
                  <h3 className="gamma-factor-title">Communication is Critical</h3>
                  <p className="gamma-factor-text">Ensure all stakeholders are promptly informed.</p>
                </div>
                <div className="gamma-factor">
                  <h3 className="gamma-factor-title">Document Everything</h3>
                  <p className="gamma-factor-text">Maintain detailed records for future reference.</p>
                </div>
                <div className="gamma-factor">
                  <h3 className="gamma-factor-title">Stay Calm & Systematic</h3>
                  <p className="gamma-factor-text">Trust the established system to guide you through.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Professional Photos */}
          <section className="gamma-section">
            <div className="gamma-photo-grid">
              <div className="gamma-photo-card">
                <div className="gamma-photo-container">
                  <div className="gamma-photo-placeholder">
                    Tim Sutton Photo
                  </div>
                </div>
                <h3 className="gamma-photo-title">Tim Sutton</h3>
                <p className="gamma-photo-subtitle">Crisis Management Expert</p>
              </div>
              <div className="gamma-photo-card">
                <div className="gamma-photo-container">
                  <div className="gamma-photo-placeholder">
                    Testimonial Quote
                  </div>
                </div>
                <h3 className="gamma-photo-title">Proven Track Record</h3>
                <p className="gamma-photo-subtitle">Industry Recognition & Results</p>
              </div>
            </div>
          </section>

          {/* Packages Section - Gamma Style */}
          <section className="gamma-section" id="packages">
            <div className="gamma-content-card">
              <h2 className="gamma-section-title">Get Your Complete Crisis Management System</h2>
              <div className="gamma-package-grid">
                <div className="gamma-package-card">
                  <h3 className="gamma-package-title">Crisis-Ready in One Day</h3>
                  <div className="gamma-package-price">$199</div>
                  <p className="gamma-package-desc">Complete 24-hour crisis management system with all templates and checklists</p>
                  <div className="gamma-package-buttons">
                    <button 
                      className="gamma-btn-primary"
                      onClick={() => window.location.href = '/checkout?package=crisis-ready&amount=199'}
                    >
                      Pay with Stripe
                    </button>
                    <a 
                      href="https://suttonian016.gumroad.com/l/etdkl"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="gamma-btn-secondary"
                    >
                      Buy on Gumroad
                    </a>
                  </div>
                </div>
                
                <div className="gamma-package-card">
                  <h3 className="gamma-package-title">Executive Crisis Plan</h3>
                  <div className="gamma-package-price">$499</div>
                  <p className="gamma-package-desc">Premium system plus personal consultation with Tim Sutton</p>
                  <div className="gamma-package-buttons">
                    <button 
                      className="gamma-btn-primary"
                      onClick={() => window.location.href = '/checkout?package=executive&amount=499'}
                    >
                      Pay with Stripe
                    </button>
                    <a 
                      href="https://suttonian016.gumroad.com/l/dxjkrs"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="gamma-btn-secondary"
                    >
                      Buy on Gumroad
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Contact Dialog */}
      <Dialog open={isQuickContactOpen} onOpenChange={setIsQuickContactOpen}>
        <DialogContent className="gamma-dialog">
          <DialogHeader>
            <DialogTitle>Contact Tim Sutton</DialogTitle>
          </DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            onSubmit(Object.fromEntries(formData));
          }}>
            <div className="gamma-form-grid">
              <input name="name" placeholder="Your Name" required className="gamma-input" />
              <input name="email" type="email" placeholder="Email" required className="gamma-input" />
              <input name="phone" placeholder="Phone" className="gamma-input" />
              <input name="company" placeholder="Company" className="gamma-input" />
              <textarea name="message" placeholder="Message" rows={4} className="gamma-textarea"></textarea>
              <button type="submit" className="gamma-btn-primary">Send Message</button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GammaReplica;