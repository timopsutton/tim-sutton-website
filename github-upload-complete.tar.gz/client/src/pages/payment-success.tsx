import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Download, ArrowRight, Home } from "lucide-react";

export default function PaymentSuccess() {
  const [, setLocation] = useLocation();
  const [packageType, setPackageType] = useState<string>("");
  const [paymentSource, setPaymentSource] = useState<string>("");

  useEffect(() => {
    // Get package type and source from URL params
    const urlParams = new URLSearchParams(window.location.search);
    const pkg = urlParams.get('package') || 'sme';
    const source = urlParams.get('source') || 'stripe';
    setPackageType(pkg);
    setPaymentSource(source);
  }, []);

  const packageDetails = packageType === 'executive' 
    ? {
        name: 'Executive Crisis Plan',
        price: '$499',
        description: 'Complete crisis management system with personal consultation'
      }
    : {
        name: 'Crisis-Ready in One Day',
        price: '$199', 
        description: '24-hour response framework for small and medium enterprises'
      };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="text-white hover:bg-white/10"
            >
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            <Badge className="bg-green-500 text-white px-3 py-1">
              PAYMENT SUCCESSFUL
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Payment Successful!
          </h1>
          <p className="text-xl text-slate-300 mb-6">
            Thank you for your purchase of <strong className="text-green-400">{packageDetails.name}</strong>
            {paymentSource === 'gumroad' && <span className="block text-sm text-blue-400 mt-2">✅ Purchased via Gumroad</span>}
          </p>
          <div className="text-3xl font-bold text-green-400">{packageDetails.price}</div>
        </div>

        {/* Access Your Materials Card */}
        <Card className="bg-gradient-to-r from-green-900/30 to-blue-900/30 border-2 border-green-500/50 mb-8">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mb-4">
                <Download className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                🎉 Your Crisis Management Materials Are Ready!
              </h2>
              <p className="text-slate-300">
                Access all your templates, playbooks, and frameworks right now
              </p>
            </div>

            <div className="space-y-4">
              <Button 
                onClick={() => setLocation('/package-preview')}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white py-6 font-bold text-lg transform hover:scale-105 transition-all duration-200 shadow-lg"
              >
                <Download className="w-6 h-6 mr-3" />
                ACCESS YOUR COMPLETE CRISIS MANAGEMENT SYSTEM
                <ArrowRight className="w-6 h-6 ml-3" />
              </Button>
              
              <div className="text-center text-slate-400 text-sm">
                ✅ Instant access • All 15+ templates included • Ready to customize
              </div>
            </div>
          </CardContent>
        </Card>

        {/* What You Get */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-black/30 border border-blue-500/20">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">📧 Email Templates</h3>
              <div className="space-y-2 text-slate-300 text-sm">
                <div>✅ 12 Professional Email Templates</div>
                <div>✅ Internal Team Communications</div>
                <div>✅ Customer Retention Messages</div>
                <div>✅ Media Statements & Press Releases</div>
                <div>✅ Stakeholder Updates</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/30 border border-green-500/20">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">📱 Social Media System</h3>
              <div className="space-y-2 text-slate-300 text-sm">
                <div>✅ 4-Level Escalation Protocol</div>
                <div>✅ Platform-Specific Templates</div>
                <div>✅ Crisis Monitoring Keywords</div>
                <div>✅ Public Response Frameworks</div>
                <div>✅ Comment Reply Templates</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/30 border border-purple-500/20">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">🏢 Industry Playbooks</h3>
              <div className="space-y-2 text-slate-300 text-sm">
                <div>✅ Restaurant Crisis Management</div>
                <div>✅ Healthcare Data Breach Protocols</div>
                <div>✅ Technology Security Incidents</div>
                <div>✅ Retail Product Issues</div>
                <div>✅ Plus 4 Additional Industries</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/30 border border-yellow-500/20">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">⚡ Immediate Access</h3>
              <div className="space-y-2 text-slate-300 text-sm">
                <div>✅ Interactive Template Selector</div>
                <div>✅ Ready-to-Customize Fields</div>
                <div>✅ Professional Formatting Included</div>
                <div>✅ Fortune 500-Level Quality</div>
                <div>✅ 24/7 Access Forever</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Executive Bonus */}
        {packageType === 'executive' && (
          <Card className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border-2 border-yellow-500/50 mb-8">
            <CardContent className="p-8">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-yellow-400 mb-4">
                  🏆 EXECUTIVE BONUS: Personal Consultation with Tim Sutton
                </h3>
                <p className="text-slate-300 mb-6">
                  Your purchase includes a 1-hour personalized strategy session with Tim Sutton himself.
                </p>
                <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4">
                  <div className="text-yellow-400 font-bold text-sm mb-2">📅 NEXT STEPS:</div>
                  <div className="text-white text-sm">
                    You will receive a separate email within 24 hours with Tim's calendar link to schedule your consultation session.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Support */}
        <div className="text-center">
          <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
            <h3 className="text-xl font-bold text-white mb-4">Need Help?</h3>
            <p className="text-slate-300 mb-4">
              If you have any questions about your purchase or need assistance with the templates, we're here to help.
            </p>
            <div className="text-slate-400 text-sm">
              📧 Contact: Direct message via your crisis management portal<br />
              🔒 Your purchase is protected by our 30-day money-back guarantee
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}