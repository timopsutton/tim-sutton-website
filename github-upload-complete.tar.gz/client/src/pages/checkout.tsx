import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from 'wouter';
import { ArrowLeft, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_live_51RivhBL41BpBXMdjAwEp1VDSYR8mWthEp6dhdbLInz86nnoK3NHCWeSxNP6BHtIeH4DYM8LJyqXizbzikc4JlurR00ljfAq2uT';
const stripePromise = loadStripe(stripePublicKey);

const CheckoutForm = ({ packageType }: { packageType: string }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (!stripe || !elements) {
      setIsProcessing(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/payment-success?package=${packageType}`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your purchase! You'll receive your crisis management materials shortly.",
      });
    }
    
    setIsProcessing(false);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <div className="flex gap-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => setLocation('/')}
          className="flex-1"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Packages
        </Button>
        <Button 
          type="submit" 
          disabled={!stripe || isProcessing}
          className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
        >
          {isProcessing ? 'Processing...' : `Pay ${packageType === 'sme' ? '$199' : '$499'}`}
        </Button>
      </div>
    </form>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [packageType, setPackageType] = useState("sme");
  const [packageDetails, setPackageDetails] = useState<any>(null);

  useEffect(() => {
    // Get package type from URL params
    const urlParams = new URLSearchParams(window.location.search);
    const pkg = urlParams.get('package') || 'sme';
    setPackageType(pkg);

    // Set package details
    const details = pkg === 'executive' 
      ? { 
          name: 'Executive Crisis Command', 
          price: 499, 
          description: 'Complete crisis management system with personal consultation'
        }
      : { 
          name: 'Crisis Management Plan for SMEs', 
          price: 199,
          description: '24-hour response framework for small and medium enterprises'
        };
    
    setPackageDetails(details);

    // Create PaymentIntent
    apiRequest("POST", "/api/create-payment-intent", { 
      amount: details.price,
      packageType: pkg,
      description: details.description
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch((error) => {
        console.error('Payment setup error:', error);
      });
  }, []);

  // Check if Stripe is properly configured
  if (!stripePromise) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-8 max-w-md text-center">
          <h2 className="text-xl font-bold text-white mb-4">Payment Setup Required</h2>
          <p className="text-slate-300 mb-6">
            Stripe payment processing is not yet configured. Please contact support or use the Gumroad payment option.
          </p>
          <Button onClick={() => window.location.href = '/'} variant="outline">
            Return to Packages
          </Button>
        </div>
      </div>
    );
  }

  if (!clientSecret || !packageDetails) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-slate-300">Setting up secure payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">{packageDetails.name}</h1>
            <p className="text-slate-400 mb-4">{packageDetails.description}</p>
            <div className="text-4xl font-bold text-blue-400">${packageDetails.price}</div>
          </div>

          <Elements stripe={stripePromise} options={{ 
            clientSecret,
            appearance: {
              theme: 'night',
              variables: {
                colorPrimary: '#3b82f6',
                colorBackground: '#1e293b',
                colorText: '#f8fafc',
                colorDanger: '#ef4444',
                borderRadius: '8px'
              }
            }
          }}>
            <CheckoutForm packageType={packageType} />
          </Elements>

          <div className="mt-6 flex items-center justify-center space-x-4 text-sm text-slate-400">
            <div className="flex items-center">
              <Shield className="w-4 h-4 mr-1 text-green-400" />
              SSL Secured
            </div>
            <div>30-day money-back guarantee</div>
          </div>
        </div>
      </div>
    </div>
  );
}