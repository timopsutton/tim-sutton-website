import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, Download, FileText, Users, Clock, Shield, AlertTriangle, Lightbulb, Target, ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';
import { useState } from 'react';

export default function PackagePreview() {
  const [, setLocation] = useLocation();
  const [selectedIndustry, setSelectedIndustry] = useState('restaurant');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            <Badge className="bg-blue-500 text-white px-3 py-1">
              PACKAGE PREVIEW
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Package Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mb-6">
            <Download className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl lg:text-5xl font-black text-white leading-tight mb-6">
            Crisis-Ready in One Day
          </h1>
          <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-lg p-4 mb-6 max-w-4xl mx-auto">
            <p className="text-blue-300 font-semibold text-sm mb-2">📚 COMPLETE SME DIGITAL PRODUCT PORTFOLIO INCLUDED</p>
            <p className="text-slate-300 text-sm">
              Crisis Management + PR & Marketing Solutions specifically designed for Small & Medium Enterprises
            </p>
          </div>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed mb-8">
            Here's exactly what customers receive - a comprehensive, professional crisis management system with industry-specific playbooks:
          </p>
          <div className="text-5xl font-black text-blue-400 mb-2">$199</div>
          <div className="text-green-400 font-bold text-lg">Instant Digital Download</div>
        </div>

        {/* Sample Template Section */}
        <div className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-lg p-6 mb-8 border border-purple-500/20">
          <h3 className="text-2xl font-bold text-white mb-4">📧 Sample Professional Template (You Get 15+ Complete Templates)</h3>
          <div className="bg-black/40 rounded-lg p-4 font-mono text-sm">
            <div className="text-purple-300 font-bold mb-3">CUSTOMER COMMUNICATION TEMPLATE</div>
            <div className="text-gray-300 leading-relaxed">
              <div className="text-blue-300">Subject: Important Update Regarding [SITUATION]</div>
              <br />
              <div>Dear Valued Customers,</div>
              <br />
              <div>We want to inform you about [BRIEF DESCRIPTION OF SITUATION]. We are taking immediate action to [CORRECTIVE MEASURES].</div>
              <br />
              <div className="text-green-300">What we're doing:</div>
              <div>[ACTION 1]</div>
              <div>[ACTION 2]</div>
              <div>[ACTION 3]</div>
              <br />
              <div>We will provide updates every [TIMEFRAME] and expect full resolution by [ESTIMATED TIME].</div>
              <br />
              <div>For questions: [CONTACT INFORMATION]</div>
              <br />
              <div>Thank you for your patience and continued trust.</div>
              <br />
              <div>[COMPANY NAME]</div>
            </div>
          </div>
          <p className="text-slate-300 text-sm mt-3 italic">
            ✅ This is just 1 of 15+ ready-to-send professional templates included in your download
          </p>
        </div>

        {/* Sample Industry Playbook */}
        <div className="bg-gradient-to-r from-red-900/30 to-orange-900/30 rounded-lg p-6 mb-8 border border-red-500/20">
          <h3 className="text-2xl font-bold text-white mb-4">🍽️ Sample Industry Playbook: Restaurant Food Safety Crisis</h3>
          <div className="bg-black/40 rounded-lg p-4">
            <div className="text-red-300 font-bold mb-3">IMMEDIATE ACTIONS (First 2 Hours):</div>
            <ul className="text-gray-300 space-y-2 ml-4">
              <li className="flex items-start"><span className="text-red-400 mr-2">•</span>Stop serving suspected contaminated food immediately</li>
              <li className="flex items-start"><span className="text-red-400 mr-2">•</span>Preserve samples of suspected food for testing</li>
              <li className="flex items-start"><span className="text-red-400 mr-2">•</span>Contact local health department within 30 minutes</li>
              <li className="flex items-start"><span className="text-red-400 mr-2">•</span>Document all affected customers and symptoms</li>
              <li className="flex items-start"><span className="text-red-400 mr-2">•</span>Notify insurance company and legal counsel</li>
            </ul>
            
            <div className="text-orange-300 font-bold mb-3 mt-4">COMMUNICATION STRATEGY:</div>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-blue-300 font-semibold">Internal:</div>
                <div className="text-gray-300">"Alert all staff, implement food safety protocols"</div>
              </div>
              <div>
                <div className="text-green-300 font-semibold">Customers:</div>
                <div className="text-gray-300">"We are investigating reports of illness and have voluntarily stopped serving [ITEM] as a precaution"</div>
              </div>
            </div>
            
            <div className="text-purple-300 font-bold mb-3 mt-4">RECOVERY ACTIONS:</div>
            <ul className="text-gray-300 space-y-1 ml-4 text-sm">
              <li className="flex items-start"><span className="text-purple-400 mr-2">•</span>Deep sanitization of entire facility</li>
              <li className="flex items-start"><span className="text-purple-400 mr-2">•</span>Staff retraining on food safety protocols</li>
              <li className="flex items-start"><span className="text-purple-400 mr-2">•</span>Third-party food safety audit</li>
              <li className="flex items-start"><span className="text-purple-400 mr-2">•</span>Gradual reopening with enhanced safety measures</li>
            </ul>
          </div>
          <p className="text-slate-300 text-sm mt-3 italic">
            ✅ This is just 1 of 8 complete industry-specific crisis playbooks (24+ crisis scenarios total)
          </p>
        </div>

        {/* Social Media Template Sample */}
        <div className="bg-gradient-to-r from-green-900/30 to-blue-900/30 rounded-lg p-6 mb-8 border border-green-500/20">
          <h3 className="text-2xl font-bold text-white mb-4">📱 4-Level Social Media Escalation System (Complete Templates)</h3>
          <div className="space-y-4">
            <div className="bg-black/40 rounded-lg p-3">
              <div className="text-green-300 font-bold text-sm mb-2">LEVEL 1 - Initial Response (Within 1 Hour)</div>
              <div className="text-gray-300 text-sm italic">
                "Hi [USERNAME], thank you for bringing this to our attention. We're looking into this right away and will get back to you within [TIMEFRAME]. Please DM us your contact details so we can follow up directly. We appreciate your patience."
              </div>
            </div>
            <div className="bg-black/40 rounded-lg p-3">
              <div className="text-yellow-300 font-bold text-sm mb-2">LEVEL 2 - Follow-Up Response (If Issue Persists)</div>
              <div className="text-gray-300 text-sm italic">
                "Hi [USERNAME], we understand your frustration and want to make this right. We've escalated your concern to our [DEPARTMENT] team. Our manager [NAME] will contact you directly at [CONTACT METHOD] within [TIMEFRAME]. We're committed to resolving this for you."
              </div>
            </div>
            <div className="bg-black/40 rounded-lg p-3">
              <div className="text-red-300 font-bold text-sm mb-2">LEVEL 4 - Public Acknowledgment (For Viral Issues)</div>
              <div className="text-gray-300 text-sm italic">
                "We're aware that several customers are experiencing [ISSUE] and we want to address this publicly. We sincerely apologize and are working around the clock to resolve this. Here's what we're doing: [ACTIONS]. We'll provide updates every [TIMEFRAME] until this is resolved."
              </div>
            </div>
          </div>
          <p className="text-slate-300 text-sm mt-3 italic">
            ✅ Complete 4-level escalation system with templates for Facebook, Instagram, Twitter, and LinkedIn
          </p>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Core Crisis Framework */}
          <Card className="bg-blue-900/20 backdrop-blur-sm border-blue-500/30">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Shield className="w-6 h-6 mr-3 text-blue-400" />
                Complete 24-Hour Crisis Framework
              </h2>
              
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
                <p className="text-blue-300 text-sm font-semibold mb-2">✅ Comprehensive Professional System</p>
                <p className="text-slate-300 text-sm">
                  Customers receive Tim Sutton's complete 24-Hour Crisis Response Plan - a battle-tested, 
                  implementation-ready framework used by Fortune 500 companies.
                </p>
              </div>
              
              <div className="space-y-6">
                <div className="bg-blue-500/10 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">📋 Complete 24-Hour Implementation Framework</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Step-by-step implementation guide with specific actions for each phase
                  </p>
                  <ul className="text-slate-400 text-sm space-y-1">
                    <li>• Hours 1-2: Crisis Assessment & Classification (Type A: Cash vs Type B: Reputation)</li>
                    <li>• Hours 3-4: Immediate Response Actions & Communication Protocol Setup</li>
                    <li>• Hours 5-8: Strategic Communication Deployment & Stakeholder Management</li>
                    <li>• Hours 9-16: Monitoring Framework & Real-time Adjustment Implementation</li>
                    <li>• Hours 17-24: Recovery Phase & Learning Documentation</li>
                  </ul>
                </div>

                <div className="bg-blue-500/10 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">📧 Complete Professional Template Library</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Ready-to-send communication templates with professional formatting and proven response frameworks
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <div className="font-semibold text-blue-300 text-sm mb-2">Email Templates</div>
                      <ul className="text-slate-400 text-xs space-y-1">
                        <li>• Internal Team Communication Template</li>
                        <li>• Customer Communication Template</li>
                        <li>• Initial Crisis Acknowledgment Email</li>
                        <li>• Customer Retention Message Template</li>
                        <li>• Crisis Response Strategy Template</li>
                      </ul>
                    </div>
                    <div>
                      <div className="font-semibold text-green-300 text-sm mb-2">Social Media Templates</div>
                      <ul className="text-slate-400 text-xs space-y-1">
                        <li>• Facebook/Instagram Public Response</li>
                        <li>• Social Media Comment Replies</li>
                        <li>• Story Templates for Crisis Updates</li>
                        <li>• 4-Level Social Media Escalation System</li>
                        <li>• Platform-Specific Crisis Responses</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-500/10 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">🎯 Complete Industry-Specific Crisis Playbooks</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Detailed step-by-step crisis response protocols for 8 major business sectors. Each playbook includes immediate actions, communication strategies, and recovery plans.
                  </p>
                  <div className="space-y-4">
                    <div className="bg-black/20 rounded p-3">
                      <div className="font-semibold text-blue-300 mb-2">🍽️ Restaurant & Food Service Crisis Playbook</div>
                      <div className="text-xs text-slate-400 space-y-1">
                        <div><strong>Food Safety Crisis:</strong> 2-hour response protocol, health dept contacts, contamination procedures</div>
                        <div><strong>Negative Review Crisis:</strong> 2-hour response templates, reputation recovery strategies</div>
                        <div><strong>Staff Shortage Crisis:</strong> Critical position assessment, backup staff protocols</div>
                      </div>
                    </div>
                    <div className="bg-black/20 rounded p-3">
                      <div className="font-semibold text-green-300 mb-2">🏥 Healthcare/Medical Practice Crisis Playbook</div>
                      <div className="text-xs text-slate-400 space-y-1">
                        <div><strong>Patient Data Breach (HIPAA):</strong> 1-hour isolation protocol, HHS notification templates</div>
                        <div><strong>Malpractice Allegations:</strong> Insurance contact procedures, documentation protocols</div>
                        <div><strong>Staffing Crisis:</strong> Patient care prioritization, emergency coverage systems</div>
                      </div>
                    </div>
                    <div className="bg-black/20 rounded p-3">
                      <div className="font-semibold text-purple-300 mb-2">💻 Technology/Software Company Crisis Playbook</div>
                      <div className="text-xs text-slate-400 space-y-1">
                        <div><strong>Data Breach/Cybersecurity:</strong> 1-hour system isolation, 72-hour customer notification</div>
                        <div><strong>Service Outage/Downtime:</strong> Technical response teams, customer communication</div>
                        <div><strong>Software Bug/Product Defects:</strong> Severity assessment, fix deployment procedures</div>
                      </div>
                    </div>
                    <div className="text-center text-slate-400 text-xs mt-3">
                      + 5 Additional Complete Industry Playbooks: Retail, Manufacturing, Professional Services, Transportation, Hospitality
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Implementation Tools & Templates */}
          <Card className="bg-green-900/20 backdrop-blur-sm border-green-500/30">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Target className="w-6 h-6 mr-3 text-green-400" />
                Professional Implementation Tools
              </h2>
              
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-6">
                <p className="text-green-300 text-sm font-semibold mb-2">✅ Battle-Tested Professional System</p>
                <p className="text-slate-300 text-sm">
                  Tim Sutton's proven framework includes all the tools and templates needed 
                  for immediate implementation - no additional resources required.
                </p>
              </div>
              
              <div className="space-y-6">
                <div className="bg-white/5 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">🚀 BONUS: Complete PR & Marketing Solutions</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Additional professional PR & marketing toolkits included at no extra cost (normally $299+ value)
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <div className="font-semibold text-purple-300 text-sm mb-2">PR Strategy Tools</div>
                      <ul className="text-slate-400 text-xs space-y-1">
                        <li>• DIY PR Strategy Toolkit</li>
                        <li>• Media Outreach "in a Box"</li>
                        <li>• Content Creation Starter Pack</li>
                        <li>• "Become a Local Influencer" Kit</li>
                        <li>• PR Measurement Dashboard</li>
                      </ul>
                    </div>
                    <div>
                      <div className="font-semibold text-yellow-300 text-sm mb-2">Marketing Solutions</div>
                      <ul className="text-slate-400 text-xs space-y-1">
                        <li>• SEO for PR Toolkit</li>
                        <li>• Partnership & Collaboration Pack</li>
                        <li>• Employee Advocacy Starter Kit</li>
                        <li>• Digital Ad Campaign Blueprints</li>
                        <li>• Customer Testimonial & Review Kit</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">📋 Crisis Management Frameworks</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Professional frameworks for systematic crisis response
                  </p>
                  <ul className="text-slate-400 text-sm space-y-1">
                    <li>• Crisis Response Strategy Template (4-part structure)</li>
                    <li>• Cost Reduction Framework (Personnel & Operational)</li>
                    <li>• Legal Risk Assessment Framework</li>
                    <li>• Client Retention Strategy Framework</li>
                    <li>• Monitoring & Adjustment Framework</li>
                  </ul>
                </div>

                <div className="bg-white/5 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">🔄 Ongoing Maintenance System</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Complete maintenance schedule to keep crisis plan current
                  </p>
                  <ul className="text-slate-400 text-sm space-y-1">
                    <li>• Weekly: Social media monitoring & financial health checks</li>
                    <li>• Monthly: Communication system testing & risk assessment</li>
                    <li>• Quarterly: Full crisis simulation exercises</li>
                    <li>• Annual: Complete plan review & team training</li>
                  </ul>
                </div>

                <div className="bg-white/5 rounded-lg p-4">
                  <h3 className="font-bold text-white mb-2">📊 ROI & Cost Analysis Tools</h3>
                  <p className="text-slate-300 text-sm mb-3">
                    Calculate and demonstrate crisis preparedness value
                  </p>
                  <ul className="text-slate-400 text-sm space-y-1">
                    <li>• ROI Calculation Template (10:1 to 50:1 typical returns)</li>
                    <li>• Crisis Cost Avoidance Calculator</li>
                    <li>• Decision Framework for Budget Allocation</li>
                    <li>• Implementation Cost vs. Crisis Cost Analysis</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sample Templates Preview */}
        <Card className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 backdrop-blur-sm border-purple-500/30 mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <FileText className="w-6 h-6 mr-3 text-purple-400" />
              Sample Communication Templates Included
            </h2>
            
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4 mb-6">
              <p className="text-purple-300 text-sm font-semibold mb-2">📧 Ready-to-Send Templates</p>
              <p className="text-slate-300 text-sm">
                Your document includes complete, written communication templates that customers can customize and use immediately.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-purple-500/10 rounded-lg p-4">
                <h3 className="font-bold text-white mb-3">📧 Professional Email Template Sample</h3>
                <div className="bg-black/30 rounded p-3 text-sm text-slate-300 font-mono">
                  <div className="text-purple-300 mb-2">Subject: Immediate Response to [SITUATION] - We're Taking Action</div>
                  <div className="text-slate-400">Dear [STAKEHOLDER/CUSTOMER NAME],</div>
                  <div className="text-slate-400 mt-2">We are writing to inform you of a situation that has come to our attention regarding [BRIEF DESCRIPTION OF CRISIS]...</div>
                  <div className="text-green-400 mt-2">What We're Doing Next: [SPECIFIC ACTIONS]</div>
                  <div className="text-blue-400 mt-2 italic">[Complete professional template with structured response format]</div>
                </div>
              </div>
              
              <div className="bg-purple-500/10 rounded-lg p-4">
                <h3 className="font-bold text-white mb-3">📱 Multi-Platform Social Media Templates</h3>
                <div className="bg-black/30 rounded p-3 text-sm text-slate-300 font-mono">
                  <div className="text-purple-300 mb-2">Facebook/Instagram Public Response:</div>
                  <div className="text-slate-400">"We are aware of the concerns regarding [SITUATION] and want to address this directly. Here's what we're doing: ✓ [ACTION 1] ✓ [ACTION 2]..."</div>
                  <div className="text-green-400 mt-2">+ Comment replies + Story templates</div>
                  <div className="text-blue-400 mt-2 italic">[Complete multi-platform crisis response suite]</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Professional Value Section */}
        <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 backdrop-blur-sm border-blue-500/30 mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Shield className="w-6 h-6 mr-3 text-yellow-400" />
              Professional Standards & Value
            </h2>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-white mb-2">Fortune 500 Quality</h3>
                <p className="text-slate-300 text-sm">
                  Same frameworks used by Tim Sutton for major corporations and global organizations
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-white mb-2">35+ Years Experience</h3>
                <p className="text-slate-300 text-sm">
                  Distilled expertise from handling 50+ crises across aviation, banking, and government
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-white mb-2">Proven Results</h3>
                <p className="text-slate-300 text-sm">
                  Multi-million dollar losses prevented, reputations protected across global markets
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Value Comparison */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Lightbulb className="w-6 h-6 mr-3 text-orange-400" />
              Value Comparison
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-bold text-red-400 mb-4 text-lg">Big Agency Approach:</h3>
                <ul className="space-y-2 text-slate-300">
                  <li className="flex items-start">
                    <AlertTriangle className="w-4 h-4 text-red-400 mr-2 mt-1" />
                    $25,000 - $50,000+ initial retainer
                  </li>
                  <li className="flex items-start">
                    <AlertTriangle className="w-4 h-4 text-red-400 mr-2 mt-1" />
                    6-8 weeks development time
                  </li>
                  <li className="flex items-start">
                    <AlertTriangle className="w-4 h-4 text-red-400 mr-2 mt-1" />
                    Multiple stakeholders and approvals
                  </li>
                  <li className="flex items-start">
                    <AlertTriangle className="w-4 h-4 text-red-400 mr-2 mt-1" />
                    Ongoing monthly fees ($5K-$15K)
                  </li>
                  <li className="flex items-start">
                    <AlertTriangle className="w-4 h-4 text-red-400 mr-2 mt-1" />
                    Generic templates and frameworks
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-bold text-green-400 mb-4 text-lg">Crisis-Ready Package:</h3>
                <ul className="space-y-2 text-slate-300">
                  <li className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-1" />
                    $199 one-time payment
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-1" />
                    Instant download, 24-hour implementation
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-1" />
                    Direct access to Tim Sutton's expertise
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-1" />
                    No ongoing fees or contracts
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-1" />
                    Battle-tested, real-world frameworks
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="mt-8 text-center bg-green-500/20 border border-green-500/30 rounded-lg p-4">
              <div className="text-green-400 font-bold text-2xl mb-2">
                You Save: $24,801+
              </div>
              <div className="text-white text-sm">
                Get the same professional quality at 0.8% of agency cost
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Delivery Requirements Section */}
        <Card className="bg-yellow-900/20 backdrop-blur-sm border-yellow-500/30 mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <AlertTriangle className="w-6 h-6 mr-3 text-yellow-400" />
              Action Required: Complete Product Delivery Setup
            </h2>
            
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-6 mb-6">
              <h3 className="font-bold text-yellow-300 mb-4 text-lg">To Ensure Customers Receive Full Value:</h3>
              <ul className="space-y-3 text-slate-300">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-400 mr-3 mt-0.5" />
                  Upload the complete 24-Hour Crisis Response Plan PDF to both Gumroad products
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5" />
                  Create additional downloadable templates (Word/Excel formats for customization)
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5" />
                  Add crisis communication template pack as separate download files
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5" />
                  Include implementation checklist in fillable PDF format
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5" />
                  Update Gumroad product descriptions to match the comprehensive content
                </li>
              </ul>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <h4 className="font-bold text-green-300 mb-2">✅ What You Have</h4>
                <p className="text-slate-300 text-sm">
                  Comprehensive 24-Hour Crisis Response Plan with professional templates, 
                  implementation guides, and crisis-specific playbooks.
                </p>
              </div>
              
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                <h4 className="font-bold text-red-300 mb-2">⚠️ What Customers Need</h4>
                <p className="text-slate-300 text-sm">
                  Access to ALL crisis management materials through Gumroad download 
                  to justify the $199 professional price point.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Next Steps to Complete Professional Delivery
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            Your crisis management content is professional and comprehensive. 
            Customers need access to ALL materials to receive full $199 value.
          </p>
          
          <div className="space-y-4">
            <Button 
              onClick={() => setLocation('/checkout?package=sme')}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 font-bold text-lg transition-all duration-300 hover:scale-105 hover:shadow-lg mr-4"
            >
              Purchase Now - $199
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => setLocation('/')}
              className="border-2 border-white/30 text-white hover:bg-white/10 px-8 py-4 font-bold text-lg"
            >
              Back to Main Site
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}