import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, ArrowLeft, CreditCard } from 'lucide-react';
import { useLocation } from 'wouter';
import { useState } from 'react';

export default function PackagePreviewInteractive() {
  const [, setLocation] = useLocation();
  const [selectedIndustry, setSelectedIndustry] = useState('restaurant');
  const [selectedTemplate, setSelectedTemplate] = useState('customer-communication');
  const [selectedSocialTemplate, setSelectedSocialTemplate] = useState('public-response');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            <Badge className="bg-blue-500 text-white px-3 py-1">
              INTERACTIVE PACKAGE PREVIEW
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Package Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mb-6">
            <Download className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            The Complete 24-Hour Crisis Management Plan
          </h1>
          <p className="text-xl text-slate-300 mb-6 max-w-3xl mx-auto">
            Transform panic into purposeful, guided action with our proven, step-by-step system that navigates you through the critical first 24 hours of any business crisis
          </p>
          
          {/* Enhanced Product Promise */}
          <div className="bg-gradient-to-r from-blue-500/20 to-orange-500/20 rounded-lg p-6 mb-8 border border-blue-500/30 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-blue-300 font-bold mb-2">TARGET PAIN POINT SOLVED:</div>
              <div className="text-white text-lg">Businesses often face overwhelming uncertainty and panic during the critical first 24 hours of a crisis, feeling lost on what to do.</div>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Badge className="bg-green-500/20 text-green-300 border border-green-500/30">
              15+ Professional Templates
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-300 border border-blue-500/30">
              8+ Industry Playbooks
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Fortune 500-Level Quality
            </Badge>
            <Badge className="bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">
              Ready-to-Implement
            </Badge>
          </div>
        </div>

        {/* Interactive Package Preview */}
        <div className="bg-gradient-to-r from-indigo-900/40 to-purple-900/40 rounded-lg p-8 mb-8 border border-indigo-500/30">
          <h2 className="text-3xl font-bold text-white mb-6 text-center">🎯 Interactive Package Explorer</h2>
          <p className="text-slate-300 text-center mb-8">Click through the tabs to explore all templates and industry playbooks included in your download</p>
          
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-black/30 rounded-lg p-1 mb-6">
              <TabsTrigger value="overview" className="text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs">
                📋 System Overview
              </TabsTrigger>
              <TabsTrigger value="immediate" className="text-white data-[state=active]:bg-red-600 data-[state=active]:text-white text-xs">
                ⚡ Hours 0-1
              </TabsTrigger>
              <TabsTrigger value="stabilization" className="text-white data-[state=active]:bg-orange-600 data-[state=active]:text-white text-xs">
                🛡️ Hours 1-6
              </TabsTrigger>
              <TabsTrigger value="strategic" className="text-white data-[state=active]:bg-green-600 data-[state=active]:text-white text-xs">
                🎯 Hours 6-12
              </TabsTrigger>
              <TabsTrigger value="templates" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white text-xs">
                📄 All Templates
              </TabsTrigger>
            </TabsList>

            {/* System Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="bg-black/30 rounded-lg p-6 border border-blue-500/20">
                <div className="text-blue-300 font-bold mb-4 text-lg">📋 COMPLETE 24-HOUR CRISIS MANAGEMENT SYSTEM</div>
                
                {/* Who This Is For */}
                <div className="mb-6 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-lg p-4 border border-blue-500/20">
                  <div className="text-cyan-300 font-bold mb-2">WHO THIS IS FOR:</div>
                  <div className="space-y-2 text-sm text-slate-300">
                    <div>• Small to mid-sized business owners navigating their first significant operational disruption</div>
                    <div>• Department managers and team leaders requiring immediate, actionable guidance</div>
                    <div>• Anyone responsible for initial crisis response who feels overwhelmed by lack of structure</div>
                    <div>• Executive leaders committed to protecting organizational reputation and financial stability</div>
                  </div>
                </div>

                {/* System Components */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gradient-to-r from-red-500/10 to-orange-500/10 rounded-lg p-4 border border-red-500/20">
                    <div className="text-red-300 font-bold mb-2">PART 1: IMMEDIATE RESPONSE (0-1h)</div>
                    <div className="text-sm text-slate-300">Rapid action, team activation, initial communication</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-orange-500/10 to-yellow-500/10 rounded-lg p-4 border border-orange-500/20">
                    <div className="text-orange-300 font-bold mb-2">PART 2: STABILIZATION (1-6h)</div>
                    <div className="text-sm text-slate-300">Assessment, stakeholder notification, resource mobilization</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-yellow-500/10 to-green-500/10 rounded-lg p-4 border border-yellow-500/20">
                    <div className="text-yellow-300 font-bold mb-2">PART 3: STRATEGIC RESPONSE (6-12h)</div>
                    <div className="text-sm text-slate-300">Long-term strategies, PR management, operational continuity</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg p-4 border border-green-500/20">
                    <div className="text-green-300 font-bold mb-2">PART 4: RECOVERY PREP (12-24h)</div>
                    <div className="text-sm text-slate-300">Post-crisis recovery, relationship rebuilding, next phase</div>
                  </div>
                </div>

                {/* Usage Modes */}
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4">
                    <div className="text-red-300 font-bold mb-2">🚨 EMERGENCY MODE (Crisis is happening NOW)</div>
                    <div className="text-sm text-slate-300 space-y-1">
                      <div>1. Go directly to PART 1</div>
                      <div>2. Follow hour-by-hour checklist</div>
                      <div>3. Use templates immediately</div>
                      <div>4. Delegate using role assignments</div>
                    </div>
                  </div>
                  
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4">
                    <div className="text-blue-300 font-bold mb-2">📚 PREPARATION MODE (Before crisis hits)</div>
                    <div className="text-sm text-slate-300 space-y-1">
                      <div>1. Read through entire system</div>
                      <div>2. Customize templates</div>
                      <div>3. Assign roles</div>
                      <div>4. Practice with exercises</div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Immediate Response Tab */}
            <TabsContent value="immediate" className="space-y-4">
              <div className="bg-black/30 rounded-lg p-6 border border-red-500/20">
                <div className="text-red-300 font-bold mb-4 text-lg">⚡ IMMEDIATE CRISIS RESPONSE (Hours 0-1)</div>
                
                {/* Hour 0 Section */}
                <div className="mb-6 bg-gradient-to-r from-red-500/10 to-orange-500/10 rounded-lg p-4 border border-red-500/20">
                  <div className="text-orange-300 font-bold mb-3">HOUR 0: CRISIS RECOGNITION AND IMMEDIATE RESPONSE</div>
                  
                  <div className="space-y-4">
                    {/* First 15 Minutes */}
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-yellow-300 font-bold mb-2">⚡ FIRST 15 MINUTES - CRISIS RECOGNITION</div>
                      <div className="text-sm text-slate-300 space-y-2">
                        <div className="flex items-start">
                          <span className="text-red-400 mr-2">1.</span>
                          <div>
                            <strong>Confirm This Is Actually a Crisis</strong><br />
                            Use Crisis Recognition Checklist - Answer: "Will this significantly impact operations, reputation, or finances?"
                          </div>
                        </div>
                        <div className="flex items-start">
                          <span className="text-red-400 mr-2">2.</span>
                          <div>
                            <strong>Activate Crisis Mode</strong><br />
                            Stop non-essential activities, clear calendar for 4+ hours, set up dedicated workspace
                          </div>
                        </div>
                        <div className="flex items-start">
                          <span className="text-red-400 mr-2">3.</span>
                          <div>
                            <strong>Initial Damage Assessment (5-minute scan)</strong><br />
                            What happened? When? Who affected? Immediate risk? Still developing?
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Minutes 15-30 */}
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-yellow-300 font-bold mb-2">⚡ MINUTES 15-30: IMMEDIATE SAFETY AND CONTAINMENT</div>
                      <div className="text-sm text-slate-300 space-y-2">
                        <div className="flex items-start">
                          <span className="text-orange-400 mr-2">1.</span>
                          <div>
                            <strong>Address Immediate Safety Issues</strong><br />
                            Are people safe? If NO → Call emergency services immediately
                          </div>
                        </div>
                        <div className="flex items-start">
                          <span className="text-orange-400 mr-2">2.</span>
                          <div>
                            <strong>Stop the Bleeding</strong><br />
                            Identify what's making situation worse, take immediate containment actions
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Minutes 30-45 */}
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-yellow-300 font-bold mb-2">⚡ MINUTES 30-45: CRISIS TEAM ACTIVATION</div>
                      <div className="text-sm text-slate-300">
                        <div className="mb-2"><strong>Crisis Team Roles:</strong></div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                          <div>• Crisis Leader (Overall decisions)</div>
                          <div>• Operations Manager (Business continuity)</div>
                          <div>• Communications Manager (All communications)</div>
                          <div>• Legal/Compliance (Legal issues)</div>
                          <div>• Finance Manager (Financial impact)</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* All Templates Tab */}
            <TabsContent value="templates" className="space-y-4">
              {/* Template Selector */}
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white mb-4">📧 Select a Template to Preview:</h3>
                <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {[
                    { id: 'internal-team', name: 'Internal Team Communication', color: 'blue' },
                    { id: 'customer-communication', name: 'Customer Communication', color: 'green' },
                    { id: 'crisis-acknowledgment', name: 'Crisis Acknowledgment', color: 'yellow' },
                    { id: 'customer-retention', name: 'Customer Retention', color: 'purple' },
                    { id: 'media-statement', name: 'Media Statement', color: 'cyan' },
                    { id: 'stakeholder-update', name: 'Stakeholder Update', color: 'orange' },
                    { id: 'data-breach', name: 'Data Breach Notice', color: 'red' },
                    { id: 'product-recall', name: 'Product Recall', color: 'pink' },
                    { id: 'staff-departure', name: 'Staff Departure', color: 'indigo' },
                    { id: 'financial-crisis', name: 'Financial Crisis', color: 'gray' },
                    { id: 'legal-compliance', name: 'Legal Compliance', color: 'emerald' },
                    { id: 'vendor-supplier', name: 'Vendor/Supplier', color: 'amber' }
                  ].map((template) => (
                    <Button
                      key={template.id}
                      variant={selectedTemplate === template.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTemplate(template.id)}
                      className={`text-xs ${selectedTemplate === template.id 
                        ? `bg-${template.color}-600 text-white` 
                        : "text-white border-white/20 hover:bg-white/10"}`}
                    >
                      {template.name}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Selected Template Display */}
              <div className="bg-black/30 rounded-lg p-6 border border-blue-500/20">
                {selectedTemplate === 'internal-team' && (
                  <>
                    <div className="text-blue-300 font-bold mb-4 text-lg">📢 INTERNAL TEAM COMMUNICATION TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4 font-mono text-sm text-gray-300">
                      <div className="text-blue-400 mb-2">Subject: URGENT - Crisis Response Activated</div>
                      <div className="mb-3">Team,</div>
                      <div className="mb-3">We are currently managing a <span className="bg-yellow-600/30 px-1">[CRISIS TYPE]</span> situation. Please follow these immediate instructions:</div>
                      <div className="mb-3 pl-4">
                        <div>• <span className="bg-red-600/30 px-1">[SPECIFIC ACTION 1]</span></div>
                        <div>• <span className="bg-red-600/30 px-1">[SPECIFIC ACTION 2]</span></div>
                        <div>• <span className="bg-red-600/30 px-1">[SPECIFIC ACTION 3]</span></div>
                      </div>
                      <div className="mb-3">⚠️ <strong>Do not communicate with external parties until further notice.</strong> All communications must go through <span className="bg-purple-600/30 px-1">[SPOKESPERSON NAME]</span>.</div>
                      <div className="mb-3">Next update: <span className="bg-green-600/30 px-1">[TIME]</span></div>
                      <div className="text-right">
                        <span className="bg-blue-600/30 px-1">[YOUR NAME]</span><br />
                        Crisis Response Leader
                      </div>
                    </div>
                  </>
                )}

                {selectedTemplate === 'customer-communication' && (
                  <>
                    <div className="text-green-300 font-bold mb-4 text-lg">📧 CUSTOMER COMMUNICATION TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4 font-mono text-sm text-gray-300">
                      <div className="text-green-400 mb-2">Subject: Important Update Regarding <span className="bg-yellow-600/30 px-1">[SITUATION]</span></div>
                      <div className="mb-3">Dear Valued Customers,</div>
                      <div className="mb-3">We want to inform you about <span className="bg-yellow-600/30 px-1">[BRIEF DESCRIPTION OF SITUATION]</span>. We are taking immediate action to <span className="bg-green-600/30 px-1">[CORRECTIVE MEASURES]</span>.</div>
                      <div className="mb-3">
                        <div className="text-green-400 font-bold">What we're doing:</div>
                        <div className="pl-4">
                          <div>✓ <span className="bg-blue-600/30 px-1">[ACTION 1]</span></div>
                          <div>✓ <span className="bg-blue-600/30 px-1">[ACTION 2]</span></div>
                          <div>✓ <span className="bg-blue-600/30 px-1">[ACTION 3]</span></div>
                        </div>
                      </div>
                      <div className="mb-3">We will provide updates every <span className="bg-purple-600/30 px-1">[TIMEFRAME]</span> and expect full resolution by <span className="bg-orange-600/30 px-1">[ESTIMATED TIME]</span>.</div>
                      <div className="mb-3">For questions: <span className="bg-cyan-600/30 px-1">[CONTACT INFORMATION]</span></div>
                      <div>Thank you for your patience and continued trust.<br /><span className="bg-blue-600/30 px-1">[COMPANY NAME]</span></div>
                    </div>
                  </>
                )}

                {selectedTemplate === 'crisis-acknowledgment' && (
                  <>
                    <div className="text-yellow-300 font-bold mb-4 text-lg">⚡ CRISIS ACKNOWLEDGMENT EMAIL TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4 font-mono text-sm text-gray-300">
                      <div className="text-yellow-400 mb-2">Subject: Immediate Response to <span className="bg-red-600/30 px-1">[SITUATION]</span> - We're Taking Action</div>
                      <div className="mb-3">Dear <span className="bg-blue-600/30 px-1">[STAKEHOLDER/CUSTOMER NAME]</span>,</div>
                      <div className="mb-3">We are writing to inform you of a situation that has come to our attention regarding <span className="bg-yellow-600/30 px-1">[BRIEF DESCRIPTION OF CRISIS]</span>. We want to be transparent and keep you informed as we work to resolve this matter.</div>
                      <div className="mb-3">
                        <div className="text-red-400 font-bold">What Happened:</div>
                        <div className="pl-4"><span className="bg-red-600/20 px-1">[CLEAR, FACTUAL DESCRIPTION OF THE INCIDENT]</span></div>
                      </div>
                      <div className="mb-3">
                        <div className="text-green-400 font-bold">Immediate Actions We've Taken:</div>
                        <div className="pl-4">
                          <div>• <span className="bg-green-600/30 px-1">[ACTION 1]</span></div>
                          <div>• <span className="bg-green-600/30 px-1">[ACTION 2]</span></div>
                          <div>• <span className="bg-green-600/30 px-1">[ACTION 3]</span></div>
                        </div>
                      </div>
                      <div className="mb-3">We sincerely apologize for any inconvenience this may cause and appreciate your patience as we work to resolve this situation quickly and thoroughly.</div>
                      <div className="mb-3">We will provide updates every <span className="bg-purple-600/30 px-1">[TIMEFRAME]</span> and are available to answer any questions at <span className="bg-cyan-600/30 px-1">[CONTACT INFORMATION]</span>.</div>
                      <div>Sincerely,<br /><span className="bg-blue-600/30 px-1">[NAME]</span><br /><span className="bg-gray-600/30 px-1">[TITLE]</span><br /><span className="bg-indigo-600/30 px-1">[COMPANY NAME]</span></div>
                    </div>
                  </>
                )}

                {selectedTemplate === 'customer-retention' && (
                  <>
                    <div className="text-purple-300 font-bold mb-4 text-lg">💎 CUSTOMER RETENTION MESSAGE TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4 font-mono text-sm text-gray-300">
                      <div className="text-purple-400 mb-2">Subject: We Value Your Business - Here's How We're Making This Right</div>
                      <div className="mb-3">Dear <span className="bg-blue-600/30 px-1">[CUSTOMER NAME]</span>,</div>
                      <div className="mb-3">As a valued customer, we want to personally reach out regarding the recent <span className="bg-yellow-600/30 px-1">[SITUATION]</span>. Your business means everything to us, and we are committed to making this right.</div>
                      <div className="mb-3">
                        <div className="text-green-400 font-bold">What We're Doing for You:</div>
                        <div className="pl-4">
                          <div>• <span className="bg-green-600/30 px-1">[SPECIFIC COMPENSATION/REMEDY 1]</span></div>
                          <div>• <span className="bg-green-600/30 px-1">[SPECIFIC COMPENSATION/REMEDY 2]</span></div>
                          <div>• <span className="bg-green-600/30 px-1">[ADDITIONAL GESTURE OF GOODWILL]</span></div>
                        </div>
                      </div>
                      <div className="mb-3">We value your business and the trust you've placed in us. Please don't hesitate to reach out to me directly with any concerns.</div>
                      <div>Best regards,<br /><span className="bg-blue-600/30 px-1">[NAME]</span><br /><span className="bg-gray-600/30 px-1">[TITLE]</span><br />📞 <span className="bg-cyan-600/30 px-1">[DIRECT PHONE]</span><br />📧 <span className="bg-cyan-600/30 px-1">[DIRECT EMAIL]</span></div>
                    </div>
                  </>
                )}

                {!['internal-team', 'customer-communication', 'crisis-acknowledgment', 'customer-retention'].includes(selectedTemplate) && (
                  <>
                    <div className="text-cyan-300 font-bold mb-4 text-lg">📋 {selectedTemplate.toUpperCase().replace('-', ' ')} TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-gray-300 text-center py-8">
                        <div className="text-yellow-400 font-bold mb-2">✅ PROFESSIONAL TEMPLATE INCLUDED</div>
                        <div className="mb-4">This template is part of your Enhanced SME Digital Product Portfolio</div>
                        <div className="text-sm space-y-2">
                          <div>• Ready-to-customize professional format</div>
                          <div>• Industry-specific compliance considerations</div>
                          <div>• Proven messaging frameworks</div>
                          <div>• Multiple communication scenarios covered</div>
                        </div>
                        <div className="mt-4 p-3 bg-blue-500/20 rounded border border-blue-500/30">
                          <strong>All 15+ templates included in your complete crisis management system</strong>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </TabsContent>

            {/* Social Media Tab */}
            <TabsContent value="social" className="space-y-4">
              {/* Social Media Template Selector */}
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white mb-4">📱 Select a Social Media Template to Preview:</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {[
                    { id: 'public-response', name: 'Public Response Post', color: 'green' },
                    { id: 'comment-replies', name: 'Comment Replies', color: 'blue' },
                    { id: 'story-updates', name: 'Story Updates', color: 'purple' },
                    { id: 'escalation-level-1', name: 'Escalation Level 1', color: 'yellow' },
                    { id: 'escalation-level-2', name: 'Escalation Level 2', color: 'orange' },
                    { id: 'escalation-level-3', name: 'Escalation Level 3', color: 'red' },
                    { id: 'escalation-level-4', name: 'Escalation Level 4', color: 'pink' },
                    { id: 'platform-specific', name: 'Platform-Specific', color: 'cyan' },
                    { id: 'monitoring-keywords', name: 'Crisis Monitoring', color: 'indigo' }
                  ].map((template) => (
                    <Button
                      key={template.id}
                      variant={selectedSocialTemplate === template.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedSocialTemplate(template.id)}
                      className={`text-xs ${selectedSocialTemplate === template.id 
                        ? `bg-${template.color}-600 text-white` 
                        : "text-white border-white/20 hover:bg-white/10"}`}
                    >
                      {template.name}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Selected Social Media Template Display */}
              <div className="bg-gradient-to-r from-green-800/30 to-blue-800/30 rounded-lg p-6 border border-green-500/20">
                {selectedSocialTemplate === 'public-response' && (
                  <>
                    <div className="text-green-300 font-bold mb-4 text-lg">📢 FACEBOOK/INSTAGRAM PUBLIC RESPONSE TEMPLATE</div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-green-400 font-semibold mb-3">Social Media Post Template:</div>
                      <div className="font-mono text-sm text-gray-300 bg-black/30 p-4 rounded leading-relaxed">
                        "We are aware of the concerns regarding <span className="bg-yellow-600/30 px-1">[SITUATION]</span> and want to address this directly. We take this matter very seriously and are investigating thoroughly. 
                        <br /><br />
                        Here's what we're doing:
                        <br />✓ <span className="bg-blue-600/30 px-1">[ACTION 1]</span>
                        <br />✓ <span className="bg-blue-600/30 px-1">[ACTION 2]</span> 
                        <br />✓ <span className="bg-blue-600/30 px-1">[ACTION 3]</span>
                        <br /><br />
                        We are committed to transparency and will share updates as we have them. 
                        <br /><br />
                        <span className="bg-purple-600/30 px-1">#[COMPANY]Cares</span> <span className="bg-purple-600/30 px-1">#Transparency</span> <span className="bg-purple-600/30 px-1">#[RELEVANT_HASHTAG]</span>"
                      </div>
                    </div>
                  </>
                )}

                {selectedSocialTemplate === 'comment-replies' && (
                  <>
                    <div className="text-blue-300 font-bold mb-4 text-lg">💬 SOCIAL MEDIA COMMENT REPLY TEMPLATES</div>
                    <div className="bg-black/40 rounded p-4 space-y-4">
                      <div>
                        <div className="text-blue-400 font-semibold mb-2">Standard Reply Template:</div>
                        <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                          "Thank you for reaching out, <span className="bg-blue-600/30 px-1">[USERNAME]</span>. We understand your concern and are taking this very seriously. We're actively working on <span className="bg-green-600/30 px-1">[SPECIFIC ACTION]</span> and will have an update by <span className="bg-orange-600/30 px-1">[TIME]</span>. Please DM us your contact info so we can follow up directly."
                        </div>
                      </div>
                      <div>
                        <div className="text-cyan-400 font-semibold mb-2">Escalated Reply Template:</div>
                        <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                          "Hi <span className="bg-blue-600/30 px-1">[USERNAME]</span>, I'm <span className="bg-purple-600/30 px-1">[NAME]</span> from our customer care team. I want to personally address your concern about <span className="bg-yellow-600/30 px-1">[ISSUE]</span>. Let's connect directly - please check your DMs."
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {selectedSocialTemplate === 'story-updates' && (
                  <>
                    <div className="text-purple-300 font-bold mb-4 text-lg">📖 INSTAGRAM/FACEBOOK STORY TEMPLATES</div>
                    <div className="bg-black/40 rounded p-4 space-y-4">
                      <div>
                        <div className="text-purple-400 font-semibold mb-2">Crisis Update Story:</div>
                        <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                          "We hear you and we're listening. 👂
                          <br /><br />
                          Swipe up for our full response and what we're doing to make this right. Your trust matters to us. 🙏
                          <br /><br />
                          <span className="bg-blue-600/30 px-1">[LINK TO FULL STATEMENT]</span>"
                        </div>
                      </div>
                      <div>
                        <div className="text-green-400 font-semibold mb-2">Behind-the-Scenes Update:</div>
                        <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                          "Taking you behind the scenes of how we're addressing <span className="bg-yellow-600/30 px-1">[SITUATION]</span>. Transparency is key to rebuilding trust. 💪
                          <br /><br />
                          Updates every <span className="bg-orange-600/30 px-1">[TIMEFRAME]</span> until resolved."
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {selectedSocialTemplate.startsWith('escalation-level') && (
                  <>
                    <div className="text-yellow-300 font-bold mb-4 text-lg">🚨 4-LEVEL SOCIAL MEDIA ESCALATION SYSTEM</div>
                    <div className="bg-black/40 rounded p-4 space-y-4">
                      {selectedSocialTemplate === 'escalation-level-1' && (
                        <div>
                          <div className="text-green-400 font-semibold mb-2">Level 1 - Initial Response (0-30 minutes):</div>
                          <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                            "Hi <span className="bg-blue-600/30 px-1">[USERNAME]</span>, thank you for bringing this to our attention. We're looking into this right away and will get back to you within <span className="bg-orange-600/30 px-1">[TIMEFRAME]</span> with an update. Your feedback is important to us."
                          </div>
                          <div className="text-gray-400 text-xs mt-2">✅ Use for: First complaints, minor issues, standard inquiries</div>
                        </div>
                      )}
                      {selectedSocialTemplate === 'escalation-level-2' && (
                        <div>
                          <div className="text-yellow-400 font-semibold mb-2">Level 2 - Management Response (30 minutes - 2 hours):</div>
                          <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                            "Hi <span className="bg-blue-600/30 px-1">[USERNAME]</span>, we understand your frustration and want to make this right. We've escalated your concern to our management team and will have a resolution by <span className="bg-orange-600/30 px-1">[TIME]</span>. Please check your DMs for direct contact."
                          </div>
                          <div className="text-gray-400 text-xs mt-2">⚠️ Use for: Repeated complaints, frustrated customers, service failures</div>
                        </div>
                      )}
                      {selectedSocialTemplate === 'escalation-level-3' && (
                        <div>
                          <div className="text-orange-400 font-semibold mb-2">Level 3 - Executive Response (2-6 hours):</div>
                          <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                            "<span className="bg-blue-600/30 px-1">[USERNAME]</span>, this is <span className="bg-purple-600/30 px-1">[NAME]</span>, <span className="bg-gray-600/30 px-1">[TITLE]</span> at <span className="bg-indigo-600/30 px-1">[COMPANY]</span>. I personally want to address your concern about <span className="bg-yellow-600/30 px-1">[ISSUE]</span> and ensure we resolve this to your satisfaction. I'll be reaching out directly."
                          </div>
                          <div className="text-gray-400 text-xs mt-2">🚨 Use for: Viral complaints, threats to leave, major service failures</div>
                        </div>
                      )}
                      {selectedSocialTemplate === 'escalation-level-4' && (
                        <div>
                          <div className="text-red-400 font-semibold mb-2">Level 4 - Public Crisis Response (Within 6 hours):</div>
                          <div className="font-mono text-sm text-gray-300 bg-black/30 p-3 rounded">
                            "We're aware that several customers are experiencing <span className="bg-red-600/30 px-1">[ISSUE]</span> and we want to address this publicly. We sincerely apologize and are working around the clock to resolve this. Here's our action plan: <span className="bg-blue-600/30 px-1">[LINK TO DETAILED RESPONSE]</span>"
                          </div>
                          <div className="text-gray-400 text-xs mt-2">🔥 Use for: Multiple complaints, trending issues, potential PR crisis</div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {!['public-response', 'comment-replies', 'story-updates'].includes(selectedSocialTemplate) && !selectedSocialTemplate.startsWith('escalation-level') && (
                  <>
                    <div className="text-cyan-300 font-bold mb-4 text-lg">📋 {selectedSocialTemplate.toUpperCase().replace('-', ' ')} SYSTEM</div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-gray-300 text-center py-8">
                        <div className="text-yellow-400 font-bold mb-2">✅ PROFESSIONAL SOCIAL MEDIA SYSTEM INCLUDED</div>
                        <div className="mb-4">This system is part of your Enhanced SME Digital Product Portfolio</div>
                        <div className="text-sm space-y-2">
                          <div>• Platform-specific response strategies</div>
                          <div>• Crisis monitoring and alert systems</div>
                          <div>• Escalation protocols and timing guidelines</div>
                          <div>• Brand voice consistency frameworks</div>
                        </div>
                        <div className="mt-4 p-3 bg-blue-500/20 rounded border border-blue-500/30">
                          <strong>Complete social media crisis management system with all templates and monitoring tools</strong>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </TabsContent>

            {/* Industry Playbooks Tab */}
            <TabsContent value="industries" className="space-y-4">
              <div className="mb-4">
                <div className="flex flex-wrap gap-2 mb-4">
                  {['restaurant', 'healthcare', 'technology', 'retail', 'manufacturing', 'services', 'transportation', 'hospitality'].map((industry) => (
                    <Button
                      key={industry}
                      variant={selectedIndustry === industry ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedIndustry(industry)}
                      className={selectedIndustry === industry ? "bg-purple-600 text-white" : "text-white border-white/20 hover:bg-white/10"}
                    >
                      {industry.charAt(0).toUpperCase() + industry.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              {selectedIndustry === 'restaurant' && (
                <div className="bg-gradient-to-r from-red-900/30 to-orange-900/30 rounded-lg p-6 border border-red-500/30">
                  <h3 className="text-2xl font-bold text-white mb-4">🍽️ Restaurant Food Safety Crisis Playbook</h3>
                  <div className="space-y-4">
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-red-300 font-bold mb-2">IMMEDIATE ACTIONS (0-2 Hours)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>✅ Contact local health department immediately</div>
                        <div>✅ Isolate all suspected food products and preserve samples</div>
                        <div>✅ Document all affected customers and their contact information</div>
                        <div>✅ Activate crisis response team (GM, Head Chef, PR contact)</div>
                        <div>✅ Prepare holding statement for media inquiries</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-orange-300 font-bold mb-2">COMMUNICATION STRATEGY (2-6 Hours)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>📧 Email all affected customers with acknowledgment and next steps</div>
                        <div>📱 Post public statement on all social media channels</div>
                        <div>📞 Prepare FAQ for customer service team</div>
                        <div>📺 Coordinate with local media contacts</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-green-300 font-bold mb-2">RECOVERY PLAN (24-72 Hours)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>🔍 Complete investigation with health authorities</div>
                        <div>🧹 Deep sanitization and staff retraining</div>
                        <div>💰 Customer compensation program implementation</div>
                        <div>📈 Reputation recovery campaign launch</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedIndustry === 'healthcare' && (
                <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 rounded-lg p-6 border border-blue-500/30">
                  <h3 className="text-2xl font-bold text-white mb-4">🏥 Healthcare Data Breach Crisis Playbook</h3>
                  <div className="space-y-4">
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-blue-300 font-bold mb-2">IMMEDIATE ACTIONS (0-1 Hour)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>✅ Isolate affected systems immediately</div>
                        <div>✅ Activate incident response team</div>
                        <div>✅ Document breach scope and affected patient records</div>
                        <div>✅ Notify HIPAA compliance officer</div>
                        <div>✅ Preserve all evidence and logs</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-cyan-300 font-bold mb-2">REGULATORY COMPLIANCE (1-72 Hours)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>📋 HHS notification within 60 days (72 hours if &gt;500 patients)</div>
                        <div>📧 Patient notification within 60 days</div>
                        <div>📺 Media notification if &gt;500 patients affected</div>
                        <div>🔐 Business Associate notification if applicable</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-green-300 font-bold mb-2">PATIENT COMMUNICATION</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>💌 Individual patient letters with breach details</div>
                        <div>📞 Dedicated hotline for patient inquiries</div>
                        <div>🛡️ Credit monitoring services if PHI includes SSN</div>
                        <div>📖 Public FAQ addressing common concerns</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedIndustry === 'technology' && (
                <div className="bg-gradient-to-r from-purple-900/30 to-indigo-900/30 rounded-lg p-6 border border-purple-500/30">
                  <h3 className="text-2xl font-bold text-white mb-4">💻 Technology Data Breach Crisis Playbook</h3>
                  <div className="space-y-4">
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-purple-300 font-bold mb-2">IMMEDIATE CONTAINMENT (0-1 Hour)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>✅ Isolate compromised systems from network</div>
                        <div>✅ Activate security incident response team</div>
                        <div>✅ Assess scope: user data, payment info, system access</div>
                        <div>✅ Preserve evidence and maintain chain of custody</div>
                        <div>✅ Change all administrative passwords</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-indigo-300 font-bold mb-2">USER NOTIFICATION (1-72 Hours)</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>📧 Email notification to all affected users</div>
                        <div>📱 In-app notification for active users</div>
                        <div>🔐 Force password reset for all affected accounts</div>
                        <div>📞 Set up dedicated customer support line</div>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded p-4">
                      <div className="text-green-300 font-bold mb-2">REGULATORY & LEGAL</div>
                      <div className="text-gray-300 text-sm space-y-1">
                        <div>⚖️ Legal counsel consultation within 2 hours</div>
                        <div>🏛️ Regulatory notifications (GDPR 72hrs, state laws vary)</div>
                        <div>💳 Payment processor notification if card data involved</div>
                        <div>🔍 Third-party forensic investigation</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Show placeholder for other industries */}
              {!['restaurant', 'healthcare', 'technology'].includes(selectedIndustry) && (
                <div className="bg-gradient-to-r from-gray-800/30 to-slate-800/30 rounded-lg p-6 border border-gray-500/30">
                  <h3 className="text-2xl font-bold text-white mb-4">🏢 {selectedIndustry.charAt(0).toUpperCase() + selectedIndustry.slice(1)} Industry Crisis Playbook</h3>
                  <div className="bg-black/40 rounded p-4">
                    <div className="text-yellow-300 font-bold mb-2">COMPLETE INDUSTRY PLAYBOOKS INCLUDED</div>
                    <div className="text-gray-300 text-sm space-y-2">
                      <div>✅ Industry-specific crisis scenarios and response protocols</div>
                      <div>✅ Regulatory compliance requirements and notification timelines</div>
                      <div>✅ Stakeholder communication templates tailored for your sector</div>
                      <div>✅ Recovery strategies designed for industry-specific challenges</div>
                      <div>✅ Media response guidance for sector-relevant crisis types</div>
                      <div className="mt-4 p-3 bg-blue-500/20 rounded border border-blue-500/30">
                        <strong>Your Enhanced SME Digital Product Portfolio includes detailed playbooks for 8+ industries with specific protocols, templates, and recovery strategies for each sector.</strong>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          <div className="text-center mt-8 p-4 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg border border-blue-500/30">
            <p className="text-white font-bold text-lg mb-2">✅ Complete Interactive Crisis Management System</p>
            <p className="text-slate-300 text-sm">15+ Professional Templates • Social Media Crisis System • 8+ Industry-Specific Playbooks • Ready-to-implement frameworks used by Fortune 500 companies</p>
          </div>
        </div>

        {/* Purchase Options */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* SME Package */}
          <Card className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border-2 border-blue-500/50">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <Badge className="bg-green-500 text-white px-3 py-1 mb-4">
                  MOST POPULAR
                </Badge>
                <h3 className="text-2xl font-bold text-white mb-2">Crisis-Ready in One Day</h3>
                <div className="text-4xl font-bold text-blue-400 mb-2">$199</div>
                <p className="text-slate-300 text-sm">Complete crisis management system</p>
              </div>
              
              <div className="space-y-4 mb-6">
                <Button 
                  onClick={() => setLocation('/checkout?package=sme')}
                  className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white py-4 font-bold text-lg"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Pay with Stripe
                </Button>
                
                <Button
                  onClick={() => window.open('https://suttonian016.gumroad.com/l/etdkl', '_blank')}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-4 font-bold text-lg"
                >
                  Pay with Gumroad
                </Button>
              </div>
              
              <div className="text-xs text-slate-400 text-center">
                30-day money-back guarantee • Instant access
              </div>
            </CardContent>
          </Card>

          {/* Executive Package */}
          <Card className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-2 border-purple-500/50">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <Badge className="bg-yellow-500 text-black px-3 py-1 mb-4">
                  INCLUDES CONSULTATION
                </Badge>
                <h3 className="text-2xl font-bold text-white mb-2">Executive Crisis Plan</h3>
                <div className="text-4xl font-bold text-purple-400 mb-2">$499</div>
                <p className="text-slate-300 text-sm">Everything + personal Tim Sutton session</p>
              </div>
              
              <div className="space-y-4 mb-6">
                <Button 
                  onClick={() => setLocation('/checkout?package=executive')}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-4 font-bold text-lg"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Pay with Stripe
                </Button>
                
                <Button
                  onClick={() => window.open('https://suttonian016.gumroad.com/l/dxjkrs', '_blank')}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-4 font-bold text-lg"
                >
                  Pay with Gumroad
                </Button>
              </div>
              
              <div className="text-xs text-slate-400 text-center">
                30-day money-back guarantee • Instant access • Personal consultation
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Interactive Package Preview Complete
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            This interactive preview shows customers exactly what comprehensive professional materials they'll receive for $199.
          </p>
          
          <div className="space-y-4">
            <Button 
              onClick={() => setLocation('/')}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 font-bold text-lg transition-all duration-300 hover:scale-105 hover:shadow-lg mr-4"
            >
              Back to Main Site
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}