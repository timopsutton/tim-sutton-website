import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  Award, 
  Shield, 
  Clock, 
  Download, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle,
  Mail,
  Globe,
  Star,
  ExternalLink,
  Menu,
  X,
  Trophy,
  BarChart3,
  MessageSquare,
  Lightbulb,
  ChevronDown
} from "lucide-react";
import timSuttonPhoto from "@assets/Picture1_1752830766958.jpg";
import timSuttonLogo from "@assets/Tim_Sutton_Strategy_Consulting_Logo_1752833515452.png";
import sabreAwardsLogo from "@assets/image_1752833967659.png";
import prWeekAwardsLogo from "@assets/image_1752834167950.png";
import goldStandardAwardsLogo from "@assets/image_1752834279751.png";
import iccoGlobalAwardsLogo from "@assets/image_1752834467399.png";
import iccoGlobalAwardsLogo2 from "@assets/image_1752835184591.png";
import iccoGlobalAwardsLogo3 from "@assets/image_1752835269384.png";
import iccoGlobalAwardsLogo4 from "@assets/image_1752835549451.png";
import iccoGlobalAwardsLogo5 from "@assets/image_1752836451392.png";
import goldStandardAwards2011Logo from "@assets/image_1752836817624.png";
import ciprLogo from "@assets/Screenshot 2025-07-18 at 11.49.50_1752835873668.png";

export default function Home() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    serviceInterest: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent",
      description: "Thank you for your inquiry. We'll get back to you within 24 hours.",
    });
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      company: "",
      serviceInterest: "",
      message: ""
    });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  return (
    <div className="min-h-screen bg-slate-50" data-version="nav-fix-final">
      {/* Navigation */}
      <header role="banner">
        <nav className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50" role="navigation" aria-label="Main navigation">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-32">
              <div className="flex items-center space-x-6">
                <img 
                  src={timSuttonLogo} 
                  alt="Tim Sutton Strategy Consulting - Crisis Management Expert Logo" 
                  className="h-28 w-auto"
                  width="112" 
                  height="112"
                />
                <div className="text-2xl lg:text-3xl font-bold text-primary leading-tight">
                  <h1 className="text-2xl lg:text-3xl font-bold">Tim Sutton</h1>
                  <h2 className="text-2xl lg:text-3xl font-bold">Strategy Consulting</h2>
                </div>
              </div>
              <div className="hidden md:flex items-center space-x-8">
                <button onClick={() => scrollToSection('about')} className="text-slate-600 hover:text-primary transition-colors" aria-label="Navigate to About section">About Tim</button>
                <button onClick={() => scrollToSection('packages')} className="text-slate-600 hover:text-primary transition-colors" aria-label="Navigate to Packages section">Digital Crisis Solutions</button>
                <Button onClick={() => scrollToSection('contact')} className="bg-primary text-white hover:bg-blue-800" aria-label="Navigate to Contact section">Contact</Button>
              </div>
              <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-slate-600 hover:text-primary"
              >
                {mobileMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-200 shadow-lg">
            <div className="px-4 py-2 space-y-2">
              <button onClick={() => scrollToSection('about')} className="block w-full text-left px-3 py-2 text-slate-600 hover:text-primary hover:bg-slate-50 rounded-md transition-colors">About Tim</button>
              <button onClick={() => scrollToSection('packages')} className="block w-full text-left px-3 py-2 text-slate-600 hover:text-primary hover:bg-slate-50 rounded-md transition-colors">Digital Crisis Solutions</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left px-3 py-2 text-slate-600 hover:text-primary hover:bg-slate-50 rounded-md transition-colors">Contact</button>
            </div>
          </div>
        )}
        </nav>
      </header>

      {/* Moving Awards Banner */}
      <div className="bg-white border-b border-slate-200 overflow-hidden">
        <div className="animate-scroll whitespace-nowrap py-4">
          <div className="inline-flex items-center space-x-24">
            {/* 5 Key Awards */}
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={sabreAwardsLogo} alt="SABRE Awards Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Winner Individual Achievement Award 2020</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={prWeekAwardsLogo} alt="PR Week Awards Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">PR Agency Head of the Year 2015</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={goldStandardAwards2011Logo} alt="Gold Standard Awards 2011 Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Winner Gold Standard Award 2011</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={iccoGlobalAwardsLogo5} alt="ICCO Global Awards 2015 Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">ICCO Global Awards 2015</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={ciprLogo} alt="CIPR Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Sword of Excellence for Best PR Campaign UK</span>
            </div>
            
            {/* Duplicate set for seamless scrolling */}
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={sabreAwardsLogo} alt="SABRE Awards Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Winner Individual Achievement Award 2020</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={prWeekAwardsLogo} alt="PR Week Awards Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">PR Agency Head of the Year 2015</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={goldStandardAwards2011Logo} alt="Gold Standard Awards 2011 Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Winner Gold Standard Award 2011</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={iccoGlobalAwardsLogo5} alt="ICCO Global Awards 2015 Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">ICCO Global Awards 2015</span>
            </div>
            <div className="inline-flex items-center space-x-4 text-slate-700">
              <img src={ciprLogo} alt="CIPR Logo" className="h-12 w-auto" />
              <span className="text-lg font-semibold">Sword of Excellence for Best PR Campaign UK</span>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-primary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-accent text-secondary mb-4 text-sm font-medium">
                Award-Winning Crisis Management Expert
              </Badge>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight hero-text">
                Crisis Management Consultant | Strategic Communications Expert
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Award-winning crisis management consultant with 35+ years experience. $320M+ in crisis losses prevented. 24/7 emergency response for SMEs and Fortune 500 companies worldwide.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => scrollToSection('packages')} 
                  className="border-2 border-white bg-transparent text-white px-8 py-3 font-semibold hover:bg-white hover:text-primary transition-colors rounded-md"
                  style={{ 
                    color: 'white !important',
                    borderColor: 'white',
                    backgroundColor: 'transparent'
                  }}
                >
                  View Crisis Packages
                </button>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="border-2 border-white bg-transparent text-white px-8 py-3 font-semibold hover:bg-white hover:text-primary transition-colors rounded-md"
                  style={{ 
                    color: 'white !important',
                    borderColor: 'white',
                    backgroundColor: 'transparent'
                  }}
                >
                  Schedule Consultation
                </button>
              </div>
            </div>
            <div className="flex justify-center">
              <img 
                src={timSuttonPhoto} 
                alt="Tim Sutton - Professional Crisis Management Consultant" 
                className="rounded-2xl shadow-2xl w-80 h-80 object-cover border-4 border-white/20"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Improved CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-8 lg:p-12 text-center shadow-xl">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-amber-600 rounded-full mb-4">
                <Download className="text-white text-xl" />
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4 leading-tight">
                GET Instant 24/7 Crisis Solution Package for SMEs
              </h2>
              <p className="text-xl text-slate-800 mb-8 max-w-2xl mx-auto font-semibold">
                Professional crisis management frameworks ready for immediate download. Battle-tested solutions used by Fortune 500 companies, now accessible for SMEs.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <button 
                onClick={() => scrollToSection('packages')} 
                className="border-2 border-gray-600 bg-transparent text-black px-8 py-4 font-bold text-lg shadow-lg rounded-md hover:bg-gray-50 transition-colors inline-flex items-center"
                style={{ 
                  color: 'black',
                  backgroundColor: 'white',
                  border: '2px solid #666'
                }}
              >
                <TrendingUp className="mr-2 h-5 w-5" style={{ color: 'black' }} />
                <span style={{ color: 'black' }}>View Crisis Packages</span>
              </button>
              <div 
                onClick={() => scrollToSection('contact')} 
                className="cursor-pointer bg-white text-black px-8 py-4 font-bold text-lg shadow-lg rounded-md border-2 border-gray-600 hover:bg-gray-50 transition-colors inline-flex items-center"
                style={{ 
                  color: 'black',
                  backgroundColor: 'white',
                  border: '2px solid #666'
                }}
              >
                <Mail className="mr-2 h-5 w-5" style={{ color: 'black' }} />
                <span style={{ color: 'black' }}>Schedule Consultation</span>
              </div>
            </div>
            
            <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-slate-700 font-medium">
              <div className="flex items-center">
                <CheckCircle className="text-green-600 mr-2 h-5 w-5" />
                Instant Download
              </div>
              <div className="flex items-center">
                <Star className="text-green-600 mr-2 h-5 w-5" />
                Expert Consultation
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-accent mb-2">35+</div>
              <div className="text-slate-300">Years Experience</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">$320M+</div>
              <div className="text-slate-300">Crisis Losses Prevented</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">50+</div>
              <div className="text-slate-300">Crisis Resolutions</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">100%</div>
              <div className="text-slate-300">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">About Tim Sutton</h2>
              <p className="text-lg text-slate-600 mb-6">
                Chairman of W Communications and Independent Strategic Communications Counsel with over 35 years of award-winning experience. Former Chairman EMEA & Asia Pacific at Weber Shandwick, leading transformational growth and winning multiple Agency of the Year honours.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <Trophy className="text-accent mr-3" />
                  <span className="text-slate-700">Provoke Media's 'Outstanding Achievement' Sabre Award</span>
                </div>
                <div className="flex items-center">
                  <Award className="text-accent mr-3" />
                  <span className="text-slate-700">PR Week 'Asia Pacific Agency Head of the Year'</span>
                </div>
                <div className="flex items-center">
                  <BarChart3 className="text-accent mr-3" />
                  <span className="text-slate-700">Led teams trebling revenues across EMEA and Asia Pacific</span>
                </div>
              </div>
              
              <blockquote className="border-l-4 border-accent pl-6 italic text-lg text-slate-700">
                "If I can help, I will. And if I can't help you, I will find you someone who can!"
                <footer className="text-sm text-slate-500 mt-2">- Tim Sutton</footer>
              </blockquote>
            </div>
            
            <div className="space-y-6">
              <img 
                src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
                alt="Strategic planning and crisis management consultation" 
                className="rounded-xl shadow-lg w-full"
              />
              
              <Card className="bg-slate-50">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-slate-900 mb-4">Specialist Expertise</h3>
                  <ul className="space-y-2 text-slate-600">
                    <li className="flex items-center">
                      <CheckCircle className="text-green-600 mr-2 h-4 w-4" />
                      Crisis communications and issues management
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-green-600 mr-2 h-4 w-4" />
                      Strategic business transformation
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-green-600 mr-2 h-4 w-4" />
                      Board-level advisory for challenging situations
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-green-600 mr-2 h-4 w-4" />
                      International market expansion
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
              Crisis Management & Strategic Communications Services
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Expert crisis management consulting, strategic communications, and business transformation solutions for Fortune 500 companies and SMEs facing complex challenges worldwide.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
                  <AlertTriangle className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Crisis & Issues Management</h3>
                <p className="text-slate-600 mb-4">Independent board-level PR and marketing consultancy for blue chip clients</p>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• 24/7 crisis response and management</li>
                  <li>• Issues identification and mitigation</li>
                  <li>• Stakeholder communications strategy</li>
                  <li>• Reputation protection and recovery</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mb-4">
                  <Users className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Strategic Business Advisory</h3>
                <p className="text-slate-600 mb-4">Strategic business and 'trouble shooting doctor' advice for PR agencies</p>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• PR holding company advisory</li>
                  <li>• Independent PR agency consulting</li>
                  <li>• Acquisition and investment opportunities</li>
                  <li>• Business performance optimization</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Investment Advisory</h3>
                <p className="text-slate-600 mb-4">Expert guidance for investors in the PR industry across Europe and Asia</p>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Market analysis and due diligence</li>
                  <li>• Strategic investment opportunities</li>
                  <li>• Acquisition target identification</li>
                  <li>• Post-acquisition integration</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-4">
                  <Lightbulb className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Strategic Solutions</h3>
                <p className="text-slate-600 mb-4">Clear strategic vision and smart solutions for complex PR and communications challenges</p>
                <div className="grid grid-cols-2 gap-2 text-sm text-slate-600">
                  <div>• Short-term: Crisis intervention</div>
                  <div>• Mid-term: Strategic planning</div>
                  <div>• Long-term: Transformation</div>
                  <div>• Executive: Interim support</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Crisis Alert Section */}
      <section className="py-16 bg-red-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center mb-6">
            <AlertTriangle className="text-4xl text-red-400 mr-4" />
            <h2 className="text-3xl font-bold">Don't Wait Until Crisis Strikes</h2>
          </div>
          <p className="text-xl mb-6">
            Every minute without a crisis plan increases potential losses by thousands. 
            <strong className="block mt-2">70% of unprepared businesses fail within 3 years of a major crisis.</strong>
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-red-800 border-red-700">
              <CardContent className="p-4 text-center">
                <Clock className="text-red-300 text-2xl mb-2 mx-auto" />
                <h3 className="font-semibold mb-2">24-Hour Response</h3>
                <p className="text-sm text-red-100">Emergency activation ready</p>
              </CardContent>
            </Card>
            <Card className="bg-red-800 border-red-700">
              <CardContent className="p-4 text-center">
                <Download className="text-red-300 text-2xl mb-2 mx-auto" />
                <h3 className="font-semibold mb-2">Instant Download</h3>
                <p className="text-sm text-red-100">Immediate access to frameworks</p>
              </CardContent>
            </Card>
            <Card className="bg-red-800 border-red-700">
              <CardContent className="p-4 text-center">
                <Users className="text-red-300 text-2xl mb-2 mx-auto" />
                <h3 className="font-semibold mb-2">Expert Support</h3>
                <p className="text-sm text-red-100">Direct access to Tim Sutton</p>
              </CardContent>
            </Card>
          </div>
          
          <p className="text-lg mb-8"><strong>Act Now:</strong> Crisis preparation costs 10x less than crisis response</p>
          <Button 
            onClick={() => scrollToSection('packages')} 
            className="bg-white text-red-900 px-8 py-3 font-semibold hover:bg-red-50 transition-colors"
          >
            Secure Your Business Today
          </Button>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
              Crisis Management Packages | 24-Hour Response Plans
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Professional crisis management solutions and emergency response plans for SMEs. Instant digital download with expert consultation options. Proven frameworks used by Fortune 500 companies.
            </p>
            <div className="mt-4 text-primary font-semibold">
              Target Audience: Designed for SMEs with turnover around $75 million or 200+ staff
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Essential Package */}
            <Card className="border-2 border-slate-200 hover:border-primary transition-colors">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Essential Package</h3>
                  <div className="text-4xl font-bold text-primary mb-2">$199</div>
                  <p className="text-slate-600">Core crisis management framework for SMEs</p>
                </div>
                
                <div className="mb-8">
                  <h4 className="font-semibold text-slate-900 mb-4">What's Included:</h4>
                  <ul className="space-y-3 text-slate-600">
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Core crisis management framework
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Basic communication templates
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Essential response protocols
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Crisis preparation checklist
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Instant digital download
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <p className="text-sm text-slate-500">Digital download after purchase</p>
                  <p className="text-sm text-slate-500">Multiple payment options available</p>
                  <Button className="w-full bg-primary text-white py-3 font-semibold hover:bg-blue-800 transition-colors">
                    Purchase with Credit Card - $199
                  </Button>
                  <div className="text-center text-slate-500">or</div>
                  <Button 
                    variant="outline"
                    className="w-full bg-slate-100 text-slate-700 py-3 font-semibold hover:bg-slate-200 transition-colors"
                    onClick={() => window.open('https://2615275620884.gumroad.com/l/crisis-response-plan', '_blank')}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Buy on Gumroad - $199
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Executive Package */}
            <Card className="border-2 border-accent relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-accent text-white px-4 py-2 text-sm font-semibold">
                  MOST POPULAR
                </Badge>
              </div>
              
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Executive Package</h3>
                  <div className="text-4xl font-bold text-primary mb-2">$499</div>
                  <p className="text-slate-600">Complete solution with personal consultation</p>
                </div>
                
                <div className="mb-8">
                  <h4 className="font-semibold text-slate-900 mb-4">Everything in Essential, Plus:</h4>
                  <ul className="space-y-3 text-slate-600">
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Advanced communications processes
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Business-specific advice for different SME types
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Multi-section crisis response framework
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Professional crisis planning templates
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      30-minute consultation with Tim Sutton
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="text-green-600 mr-2 mt-1 h-4 w-4" />
                      Priority email support for 90 days
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <p className="text-sm text-slate-500">Digital download after purchase</p>
                  <p className="text-sm text-slate-500">Multiple payment options available</p>
                  <Button className="w-full bg-accent text-white py-3 font-semibold hover:bg-yellow-600 transition-colors">
                    Purchase with Credit Card - $499
                  </Button>
                  <div className="text-center text-slate-500">or</div>
                  <Button 
                    variant="outline"
                    className="w-full bg-slate-100 text-slate-700 py-3 font-semibold hover:bg-slate-200 transition-colors"
                    onClick={() => window.open('https://2615275620884.gumroad.com/l/crisis-response-plan?option=M5bE-KkGjcjMiaJp20GIZQ%3D%3D', '_blank')}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Buy on Gumroad - $499
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">Client Success Stories</h2>
            <p className="text-xl text-slate-600">See how our crisis management solutions have protected businesses and prevented losses.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="text-accent text-xl">
                    <MessageSquare />
                  </div>
                </div>
                <p className="text-slate-600 mb-6">
                  "Tim's crisis management framework saved our company during a major data breach. His 24-hour response and strategic guidance prevented millions in losses."
                </p>
                <div className="border-t pt-4">
                  <div className="font-semibold text-slate-900">Sarah Chen</div>
                  <div className="text-sm text-slate-600">CEO, TechCorp Ltd</div>
                  <div className="text-sm text-slate-500">200+ employees, Tech Industry</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="text-accent text-xl">
                    <MessageSquare />
                  </div>
                </div>
                <p className="text-slate-600 mb-6">
                  "The Executive Package consultation was invaluable. Tim tailored the crisis protocols specifically for our manufacturing environment. Excellent ROI."
                </p>
                <div className="border-t pt-4">
                  <div className="font-semibold text-slate-900">Michael Rodriguez</div>
                  <div className="text-sm text-slate-600">Operations Director</div>
                  <div className="text-sm text-slate-500">Manufacturing, $85M Revenue</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="text-accent text-xl">
                    <MessageSquare />
                  </div>
                </div>
                <p className="text-slate-600 mb-6">
                  "Professional, responsive, and incredibly knowledgeable. Tim's templates and frameworks are now integral to our emergency procedures."
                </p>
                <div className="border-t pt-4">
                  <div className="font-semibold text-slate-900">Jennifer Walsh</div>
                  <div className="text-sm text-slate-600">Communications Manager</div>
                  <div className="text-sm text-slate-500">Healthcare, 150+ staff</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">Get In Touch</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Ready to discuss your strategic communications needs or crisis management challenges? Let's explore how we can work together.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold text-slate-900 mb-6">Schedule a Consultation</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName" className="text-sm font-medium text-slate-700 mb-2">First Name</Label>
                    <Input 
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                      className="border-slate-300 focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-sm font-medium text-slate-700 mb-2">Last Name</Label>
                    <Input 
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                      className="border-slate-300 focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email" className="text-sm font-medium text-slate-700 mb-2">Email Address</Label>
                  <Input 
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="border-slate-300 focus:ring-2 focus:ring-primary"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="text-sm font-medium text-slate-700 mb-2">Phone Number (Optional)</Label>
                  <Input 
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="border-slate-300 focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <Label htmlFor="company" className="text-sm font-medium text-slate-700 mb-2">Company</Label>
                  <Input 
                    id="company"
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                    className="border-slate-300 focus:ring-2 focus:ring-primary"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="serviceInterest" className="text-sm font-medium text-slate-700 mb-2">Service Interest</Label>
                  <Select value={formData.serviceInterest} onValueChange={(value) => setFormData({...formData, serviceInterest: value})}>
                    <SelectTrigger className="border-slate-300 focus:ring-2 focus:ring-primary">
                      <SelectValue placeholder="Select a service..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="crisis-management">Crisis Management</SelectItem>
                      <SelectItem value="strategic-communications">Strategic Communications</SelectItem>
                      <SelectItem value="investment-advisory">Investment Advisory</SelectItem>
                      <SelectItem value="business-transformation">Business Transformation</SelectItem>
                      <SelectItem value="general-consultation">General Consultation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="message" className="text-sm font-medium text-slate-700 mb-2">Message</Label>
                  <Textarea 
                    id="message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="border-slate-300 focus:ring-2 focus:ring-primary"
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-primary text-white py-3 font-semibold hover:bg-blue-800 transition-colors">
                  Send Message
                </Button>
              </form>
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold text-slate-900 mb-6">Specialized Consulting Services Available</h3>
              <div className="grid grid-cols-2 gap-4 mb-8">
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <AlertTriangle className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Crisis Management</div>
                  </CardContent>
                </Card>
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <MessageSquare className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Strategic Communications</div>
                  </CardContent>
                </Card>
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <CheckCircle className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Issues Management</div>
                  </CardContent>
                </Card>
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <TrendingUp className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Agency Transformation</div>
                  </CardContent>
                </Card>
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <BarChart3 className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Investment Advisory</div>
                  </CardContent>
                </Card>
                <Card className="bg-slate-50 text-center">
                  <CardContent className="p-4">
                    <Users className="text-primary text-2xl mb-2 mx-auto" />
                    <div className="text-sm font-medium">Business Turnaround</div>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="bg-primary text-white">
                <CardContent className="p-6">
                  <h4 className="text-xl font-semibold mb-4">Ready to Get Started?</h4>
                  <p className="mb-6">Get in touch to discuss your strategic communications needs and explore how we can help transform your business challenges into opportunities.</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center">
                      <Clock className="mr-2 h-4 w-4" />
                      Rapid Crisis Response Available
                    </div>
                    <div className="flex items-center">
                      <Globe className="mr-2 h-4 w-4" />
                      Global Reach: Europe & Asia Pacific
                    </div>
                    <div className="flex items-center">
                      <Award className="mr-2 h-4 w-4" />
                      Award-Winning Expertise
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-xl font-bold mb-4">TS Strategy Consulting</div>
              <p className="text-slate-400 mb-4">Award-winning crisis management and strategic communications expert with 35+ years of experience.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  <Mail className="h-5 w-5" />
                </a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  <Globe className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-400">
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">Crisis Management</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">Strategic Communications</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">Investment Advisory</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">Business Transformation</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-slate-400">
                <li><button onClick={() => scrollToSection('packages')} className="hover:text-white transition-colors">Crisis Packages</button></li>
                <li><a href="#" className="hover:text-white transition-colors">Case Studies</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-white transition-colors">Contact</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-slate-400">
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4" />
                  Expert Crisis Response
                </div>
                <div className="flex items-center">
                  <Globe className="mr-2 h-4 w-4" />
                  Global Coverage
                </div>
                <div className="flex items-center">
                  <Shield className="mr-2 h-4 w-4" />
                  UK Registered Business
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2024 TS Strategy Consulting. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
